import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import {
  insertTransactionSchema,
  insertCategorySchema,
  insertBudgetSchema,
  insertBillSchema
} from "@shared/schema";
import { z } from "zod";

// Helper for checking authentication
function ensureAuth(req: Request, res: Response, next: Function) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).send("Unauthorized");
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Transactions API
  app.get("/api/transactions", ensureAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const transactions = await storage.getTransactions(userId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  app.get("/api/transactions/:id", ensureAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const transaction = await storage.getTransactionById(id);
      
      if (!transaction) {
        return res.status(404).json({ error: "Transaction not found" });
      }
      
      // Ensure user only accesses their own transactions
      if (transaction.userId !== req.user!.id) {
        return res.status(403).json({ error: "Unauthorized access" });
      }
      
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transaction" });
    }
  });

  app.post("/api/transactions", ensureAuth, async (req, res) => {
    try {
      // Always set the userId from the authenticated user
      const transactionData = {
        ...req.body,
        userId: req.user!.id
      };

      // Handle date properly
      if (typeof transactionData.date === 'string') {
        transactionData.date = new Date(transactionData.date);
      }
      
      // Parse and validate request body
      const parsedBody = insertTransactionSchema.safeParse(transactionData);
      
      if (!parsedBody.success) {
        console.error("Validation error:", parsedBody.error.errors);
        return res.status(400).json({ error: parsedBody.error.errors });
      }
      
      const transaction = await storage.createTransaction(parsedBody.data);
      res.status(201).json(transaction);
    } catch (error) {
      console.error("Transaction creation error:", error);
      res.status(500).json({ error: "Failed to create transaction" });
    }
  });

  app.patch("/api/transactions/:id", ensureAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingTransaction = await storage.getTransactionById(id);
      
      if (!existingTransaction) {
        return res.status(404).json({ error: "Transaction not found" });
      }
      
      // Ensure user only updates their own transactions
      if (existingTransaction.userId !== req.user!.id) {
        return res.status(403).json({ error: "Unauthorized access" });
      }
      
      // Validate the update fields
      const updateData = {
        ...req.body,
        userId: req.user!.id // Ensure userId can't be changed
      };

      // Handle date properly
      if (updateData.date && typeof updateData.date === 'string') {
        updateData.date = new Date(updateData.date);
      }
      
      const updated = await storage.updateTransaction(id, updateData);
      res.json(updated);
    } catch (error) {
      console.error("Transaction update error:", error);
      res.status(500).json({ error: "Failed to update transaction" });
    }
  });

  app.delete("/api/transactions/:id", ensureAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const transaction = await storage.getTransactionById(id);
      
      if (!transaction) {
        return res.status(404).json({ error: "Transaction not found" });
      }
      
      // Ensure user only deletes their own transactions
      if (transaction.userId !== req.user!.id) {
        return res.status(403).json({ error: "Unauthorized access" });
      }
      
      await storage.deleteTransaction(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete transaction" });
    }
  });

  // Categories API
  app.get("/api/categories", ensureAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const categories = await storage.getCategories(userId);
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  app.post("/api/categories", ensureAuth, async (req, res) => {
    try {
      // Parse and validate request body
      const parsedBody = insertCategorySchema.safeParse({
        ...req.body,
        userId: req.user!.id
      });
      
      if (!parsedBody.success) {
        return res.status(400).json({ error: parsedBody.error.errors });
      }
      
      const category = await storage.createCategory(parsedBody.data);
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ error: "Failed to create category" });
    }
  });

  app.put("/api/categories/:id", ensureAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingCategory = await storage.getCategoryById(id);
      
      if (!existingCategory) {
        return res.status(404).json({ error: "Category not found" });
      }
      
      // Ensure user only updates their own categories
      if (existingCategory.userId !== req.user!.id && !existingCategory.isDefault) {
        return res.status(403).json({ error: "Unauthorized access" });
      }
      
      // Validate the update fields
      const updateData = {
        ...req.body,
        userId: req.user!.id, // Ensure userId can't be changed
        isDefault: existingCategory.isDefault // Ensure isDefault can't be changed
      };
      
      const updated = await storage.updateCategory(id, updateData);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to update category" });
    }
  });

  app.delete("/api/categories/:id", ensureAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const category = await storage.getCategoryById(id);
      
      if (!category) {
        return res.status(404).json({ error: "Category not found" });
      }
      
      // Ensure user only deletes their own categories and not default ones
      if (category.userId !== req.user!.id || category.isDefault) {
        return res.status(403).json({ error: "Unauthorized access or default category" });
      }
      
      const deleted = await storage.deleteCategory(id);
      if (deleted) {
        res.status(204).send();
      } else {
        res.status(400).json({ error: "Cannot delete category" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to delete category" });
    }
  });

  // Budgets API
  app.get("/api/budgets", ensureAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const budgets = await storage.getBudgets(userId);
      res.json(budgets);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch budgets" });
    }
  });

  app.post("/api/budgets", ensureAuth, async (req, res) => {
    try {
      // Parse and validate request body
      const parsedBody = insertBudgetSchema.safeParse({
        ...req.body,
        userId: req.user!.id
      });
      
      if (!parsedBody.success) {
        return res.status(400).json({ error: parsedBody.error.errors });
      }
      
      const budget = await storage.createBudget(parsedBody.data);
      res.status(201).json(budget);
    } catch (error) {
      res.status(500).json({ error: "Failed to create budget" });
    }
  });

  app.put("/api/budgets/:id", ensureAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingBudget = await storage.getBudgetById(id);
      
      if (!existingBudget) {
        return res.status(404).json({ error: "Budget not found" });
      }
      
      // Ensure user only updates their own budgets
      if (existingBudget.userId !== req.user!.id) {
        return res.status(403).json({ error: "Unauthorized access" });
      }
      
      // Validate the update fields
      const updateData = {
        ...req.body,
        userId: req.user!.id // Ensure userId can't be changed
      };
      
      const updated = await storage.updateBudget(id, updateData);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to update budget" });
    }
  });

  app.delete("/api/budgets/:id", ensureAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const budget = await storage.getBudgetById(id);
      
      if (!budget) {
        return res.status(404).json({ error: "Budget not found" });
      }
      
      // Ensure user only deletes their own budgets
      if (budget.userId !== req.user!.id) {
        return res.status(403).json({ error: "Unauthorized access" });
      }
      
      await storage.deleteBudget(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete budget" });
    }
  });

  // Bills API
  app.get("/api/bills", ensureAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const bills = await storage.getBills(userId);
      res.json(bills);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch bills" });
    }
  });

  app.post("/api/bills", ensureAuth, async (req, res) => {
    try {
      console.log("Received bill data:", req.body);
      console.log("dueDate type:", typeof req.body.dueDate);
      console.log("dueDate value:", req.body.dueDate);
      
      // Parse and validate request body
      // Make sure dueDate is parsed as a Date object
      let bodyToValidate = {
        ...req.body,
        userId: req.user!.id
      };
      
      // If dueDate is a string, convert it to a Date object
      if (typeof bodyToValidate.dueDate === 'string') {
        try {
          bodyToValidate.dueDate = new Date(bodyToValidate.dueDate);
          console.log("Converted dueDate to Date object:", bodyToValidate.dueDate);
        } catch (e) {
          console.error("Failed to convert dueDate string to Date:", e);
        }
      }
      
      const parsedBody = insertBillSchema.safeParse(bodyToValidate);
      
      if (!parsedBody.success) {
        console.log("Validation error:", parsedBody.error.errors);
        return res.status(400).json({ error: parsedBody.error.errors });
      }
      
      const bill = await storage.createBill(parsedBody.data);
      res.status(201).json(bill);
    } catch (error) {
      res.status(500).json({ error: "Failed to create bill" });
    }
  });

  app.put("/api/bills/:id", ensureAuth, async (req, res) => {
    try {
      console.log("Update bill request:", req.body);
      console.log("dueDate type in update:", typeof req.body.dueDate);
      console.log("dueDate value in update:", req.body.dueDate);
      
      const id = parseInt(req.params.id);
      const existingBill = await storage.getBillById(id);
      
      if (!existingBill) {
        return res.status(404).json({ error: "Bill not found" });
      }
      
      // Ensure user only updates their own bills
      if (existingBill.userId !== req.user!.id) {
        return res.status(403).json({ error: "Unauthorized access" });
      }
      
      // Prepare update data with date conversion
      let updateData = {
        ...req.body,
        userId: req.user!.id // Ensure userId can't be changed
      };
      
      // Handle date conversion
      if (typeof updateData.dueDate === 'string') {
        try {
          updateData.dueDate = new Date(updateData.dueDate);
          console.log("Converted dueDate to Date object for update:", updateData.dueDate);
        } catch (e) {
          console.error("Failed to convert dueDate string to Date in update:", e);
        }
      }
      
      console.log("Final update data:", updateData);
      
      const updated = await storage.updateBill(id, updateData);
      if (!updated) {
        return res.status(404).json({ error: "Failed to update bill, bill not found" });
      }
      res.json(updated);
    } catch (error) {
      console.error("Error updating bill:", error);
      res.status(500).json({ error: "Failed to update bill" });
    }
  });

  app.delete("/api/bills/:id", ensureAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const bill = await storage.getBillById(id);
      
      if (!bill) {
        return res.status(404).json({ error: "Bill not found" });
      }
      
      // Ensure user only deletes their own bills
      if (bill.userId !== req.user!.id) {
        return res.status(403).json({ error: "Unauthorized access" });
      }
      
      await storage.deleteBill(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete bill" });
    }
  });

  // Summary API - for dashboard
  app.get("/api/summary", ensureAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const timeRange = req.query.timeRange as string || "6"; // Default to 6 months if not specified
      const categoryTimeRange = req.query.categoryTimeRange as string || "1"; // Default to 1 month for categories
      const transactions = await storage.getTransactions(userId);
      
      // Helper to get date range (default to current month)
      const getDateRange = () => {
        const now = new Date();
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
        return { start: startOfMonth, end: endOfMonth };
      };
      
      const { start, end } = getDateRange();
      
      // Filter transactions for current month
      const currentMonthTransactions = transactions.filter(t => {
        const date = new Date(t.date);
        return date >= start && date <= end;
      });
      
      // Calculate income, expenses and balance
      const income = currentMonthTransactions
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0);
        
      const expenses = currentMonthTransactions
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0);
        
      const balance = income - expenses;
      
      // Get last month's data for comparison
      const lastMonthStart = new Date(start);
      lastMonthStart.setMonth(lastMonthStart.getMonth() - 1);
      
      const lastMonthEnd = new Date(end);
      lastMonthEnd.setMonth(lastMonthEnd.getMonth() - 1);
      
      const lastMonthTransactions = transactions.filter(t => {
        const date = new Date(t.date);
        return date >= lastMonthStart && date <= lastMonthEnd;
      });
      
      const lastMonthIncome = lastMonthTransactions
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0);
        
      const lastMonthExpenses = lastMonthTransactions
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0);
      
      // Calculate percentage changes
      const incomeChange = lastMonthIncome === 0 ? 100 : ((income - lastMonthIncome) / lastMonthIncome) * 100;
      const expenseChange = lastMonthExpenses === 0 ? 100 : ((expenses - lastMonthExpenses) / lastMonthExpenses) * 100;
      
      // Get budgets and calculate overall status
      const budgets = await storage.getBudgets(userId);
      let totalBudget = 0;
      let totalSpent = 0;
      
      budgets.forEach(budget => {
        totalBudget += budget.amount;
        
        // Find expenses for this budget category
        const categoryExpenses = currentMonthTransactions
          .filter(t => t.type === 'expense' && t.categoryId === budget.categoryId)
          .reduce((sum, t) => sum + t.amount, 0);
          
        totalSpent += categoryExpenses;
      });
      
      const budgetStatus = totalBudget === 0 ? 0 : Math.min(100, Math.round((totalSpent / totalBudget) * 100));
      
      // Get upcoming bills
      const bills = await storage.getBills(userId);
      const upcomingBills = bills
        .filter(bill => !bill.paid)
        .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
        .slice(0, 3); // Get top 3 upcoming bills
      
      // Get the date range for category spending based on categoryTimeRange
      const getCategoryDateRange = () => {
        const now = new Date();
        const months = parseInt(categoryTimeRange) || 1; // Default to 1 month
        const startDate = new Date(now.getFullYear(), now.getMonth() - (months - 1), 1);
        const endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
        return { start: startDate, end: endDate };
      };
      
      const { start: categoryStart, end: categoryEnd } = getCategoryDateRange();
      
      // Filter transactions for category spending based on selected time range
      const categoryFilteredTransactions = transactions.filter(t => {
        const date = new Date(t.date);
        return date >= categoryStart && date <= categoryEnd;
      });
      
      // Calculate total expenses for the selected category time range
      const categoryExpenses = categoryFilteredTransactions
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0);
      
      // Category spending breakdown
      const categories = await storage.getCategories(userId);
      const categorySpending = categories.map(category => {
        const amount = categoryFilteredTransactions
          .filter(t => t.type === 'expense' && t.categoryId === category.id)
          .reduce((sum, t) => sum + t.amount, 0);
          
        const percentage = categoryExpenses === 0 ? 0 : Math.round((amount / categoryExpenses) * 100);
        
        return {
          id: category.id,
          name: category.name,
          color: category.color,
          icon: category.icon,
          amount,
          percentage
        };
      }).filter(c => c.amount > 0).sort((a, b) => b.amount - a.amount);
      
      // Monthly spending data based on selected time range
      const monthlyData = [];
      const today = new Date();
      const months = parseInt(timeRange) || 6; // Convert to number, default to 6 if invalid
      
      for (let i = months - 1; i >= 0; i--) {
        const monthDate = new Date(today.getFullYear(), today.getMonth() - i, 1);
        const monthStart = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
        const monthEnd = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0, 23, 59, 59);
        
        const monthTransactions = transactions.filter(t => {
          const date = new Date(t.date);
          return date >= monthStart && date <= monthEnd;
        });
        
        const monthIncome = monthTransactions
          .filter(t => t.type === 'income')
          .reduce((sum, t) => sum + t.amount, 0);
          
        const monthExpenses = monthTransactions
          .filter(t => t.type === 'expense')
          .reduce((sum, t) => sum + t.amount, 0);
        
        const monthName = monthDate.toLocaleString('default', { month: 'short' });
        
        monthlyData.push({
          month: monthName,
          income: monthIncome,
          expenses: monthExpenses
        });
      }
      
      // Budget progress data
      const budgetProgress = await Promise.all(
        budgets.map(async budget => {
          const category = await storage.getCategoryById(budget.categoryId);
          const spent = currentMonthTransactions
            .filter(t => t.type === 'expense' && t.categoryId === budget.categoryId)
            .reduce((sum, t) => sum + t.amount, 0);
            
          const percentage = Math.min(100, Math.round((spent / budget.amount) * 100));
          
          return {
            id: budget.id,
            categoryId: budget.categoryId,
            categoryName: category?.name || 'Unknown',
            amount: budget.amount,
            spent,
            percentage
          };
        })
      );
      
      res.json({
        summary: {
          income,
          expenses,
          balance,
          incomeChange,
          expenseChange,
          budgetStatus
        },
        categorySpending,
        monthlyData,
        upcomingBills,
        budgetProgress,
        recentTransactions: currentMonthTransactions
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
          .slice(0, 5)
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch summary data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
