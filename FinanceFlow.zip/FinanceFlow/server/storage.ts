import {
  User, InsertUser,
  Transaction, InsertTransaction,
  Category, InsertCategory,
  Budget, InsertBudget,
  Bill, InsertBill,
  users, transactions, categories, budgets, bills
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";
import { db, pool } from "./db";
import { eq, and, or } from "drizzle-orm";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Transaction operations
  getTransactions(userId: number): Promise<Transaction[]>;
  getTransactionById(id: number): Promise<Transaction | undefined>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: number, transaction: Partial<InsertTransaction>): Promise<Transaction | undefined>;
  deleteTransaction(id: number): Promise<boolean>;
  
  // Category operations
  getCategories(userId: number): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;
  
  // Budget operations
  getBudgets(userId: number): Promise<Budget[]>;
  getBudgetById(id: number): Promise<Budget | undefined>;
  createBudget(budget: InsertBudget): Promise<Budget>;
  updateBudget(id: number, budget: Partial<InsertBudget>): Promise<Budget | undefined>;
  deleteBudget(id: number): Promise<boolean>;
  
  // Bill operations
  getBills(userId: number): Promise<Bill[]>;
  getBillById(id: number): Promise<Bill | undefined>;
  createBill(bill: InsertBill): Promise<Bill>;
  updateBill(id: number, bill: Partial<InsertBill>): Promise<Bill | undefined>;
  deleteBill(id: number): Promise<boolean>;
  
  // Session store
  sessionStore: any;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private transactions: Map<number, Transaction>;
  private categories: Map<number, Category>;
  private budgets: Map<number, Budget>;
  private bills: Map<number, Bill>;
  private currentIds: {
    user: number;
    transaction: number;
    category: number;
    budget: number;
    bill: number;
  };
  public sessionStore: any;

  constructor() {
    this.users = new Map();
    this.transactions = new Map();
    this.categories = new Map();
    this.budgets = new Map();
    this.bills = new Map();
    this.currentIds = {
      user: 1,
      transaction: 1,
      category: 1,
      budget: 1,
      bill: 1
    };
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24 hours
    });
    
    // Create default categories
    this.seedDefaultCategories();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentIds.user++;
    const user: User = { 
      ...insertUser, 
      id,
      fullName: insertUser.fullName || null,
      email: insertUser.email || null
    };
    this.users.set(id, user);
    
    // Create default categories for the new user
    this.createDefaultCategoriesForUser(id);
    
    return user;
  }

  // Transaction operations
  async getTransactions(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(
      (transaction) => transaction.userId === userId,
    );
  }

  async getTransactionById(id: number): Promise<Transaction | undefined> {
    return this.transactions.get(id);
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.currentIds.transaction++;
    const now = new Date();
    const transaction: Transaction = { 
      ...insertTransaction, 
      id,
      date: insertTransaction.date || now,
      description: insertTransaction.description || null,
      notes: insertTransaction.notes || null
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async updateTransaction(id: number, updatedTransaction: Partial<InsertTransaction>): Promise<Transaction | undefined> {
    const transaction = this.transactions.get(id);
    if (!transaction) return undefined;
    
    const updated: Transaction = { ...transaction, ...updatedTransaction };
    this.transactions.set(id, updated);
    return updated;
  }

  async deleteTransaction(id: number): Promise<boolean> {
    return this.transactions.delete(id);
  }

  // Category operations
  async getCategories(userId: number): Promise<Category[]> {
    return Array.from(this.categories.values()).filter(
      (category) => category.userId === userId || category.isDefault,
    );
  }

  async getCategoryById(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.currentIds.category++;
    const category: Category = { 
      ...insertCategory, 
      id,
      color: insertCategory.color || null,
      icon: insertCategory.icon || null,
      isDefault: insertCategory.isDefault || false
    };
    this.categories.set(id, category);
    return category;
  }

  async updateCategory(id: number, updatedCategory: Partial<InsertCategory>): Promise<Category | undefined> {
    const category = this.categories.get(id);
    if (!category) return undefined;
    
    const updated: Category = { ...category, ...updatedCategory };
    this.categories.set(id, updated);
    return updated;
  }

  async deleteCategory(id: number): Promise<boolean> {
    const category = this.categories.get(id);
    if (!category || category.isDefault) {
      return false;
    }
    return this.categories.delete(id);
  }

  // Budget operations
  async getBudgets(userId: number): Promise<Budget[]> {
    return Array.from(this.budgets.values()).filter(
      (budget) => budget.userId === userId,
    );
  }

  async getBudgetById(id: number): Promise<Budget | undefined> {
    return this.budgets.get(id);
  }

  async createBudget(insertBudget: InsertBudget): Promise<Budget> {
    const id = this.currentIds.budget++;
    const budget: Budget = { 
      ...insertBudget, 
      id,
      endDate: insertBudget.endDate || null
    };
    this.budgets.set(id, budget);
    return budget;
  }

  async updateBudget(id: number, updatedBudget: Partial<InsertBudget>): Promise<Budget | undefined> {
    const budget = this.budgets.get(id);
    if (!budget) return undefined;
    
    const updated: Budget = { ...budget, ...updatedBudget };
    this.budgets.set(id, updated);
    return updated;
  }

  async deleteBudget(id: number): Promise<boolean> {
    return this.budgets.delete(id);
  }

  // Bill operations
  async getBills(userId: number): Promise<Bill[]> {
    return Array.from(this.bills.values()).filter(
      (bill) => bill.userId === userId,
    );
  }

  async getBillById(id: number): Promise<Bill | undefined> {
    return this.bills.get(id);
  }

  async createBill(insertBill: InsertBill): Promise<Bill> {
    const id = this.currentIds.bill++;
    const bill: Bill = { 
      ...insertBill, 
      id,
      categoryId: insertBill.categoryId || null,
      paid: insertBill.paid || false
    };
    this.bills.set(id, bill);
    return bill;
  }

  async updateBill(id: number, updatedBill: Partial<InsertBill>): Promise<Bill | undefined> {
    const bill = this.bills.get(id);
    if (!bill) return undefined;
    
    const updated: Bill = { ...bill, ...updatedBill };
    this.bills.set(id, updated);
    return updated;
  }

  async deleteBill(id: number): Promise<boolean> {
    return this.bills.delete(id);
  }

  // Helper methods for seeding default data
  private seedDefaultCategories() {
    const defaultCategories: Partial<Category>[] = [
      { name: 'Housing', color: '#3B82F6', icon: 'building' },
      { name: 'Food & Dining', color: '#10B981', icon: 'restaurant' },
      { name: 'Transportation', color: '#F59E0B', icon: 'gas-station' },
      { name: 'Entertainment', color: '#EF4444', icon: 'film' },
      { name: 'Utilities', color: '#6366F1', icon: 'plug' },
      { name: 'Healthcare', color: '#EC4899', icon: 'first-aid' },
      { name: 'Shopping', color: '#8B5CF6', icon: 'shopping-bag' },
      { name: 'Personal', color: '#14B8A6', icon: 'user' },
      { name: 'Education', color: '#F97316', icon: 'graduation-cap' },
      { name: 'Income', color: '#22C55E', icon: 'bank' }
    ];
    
    // Create default system categories (userId = 0 means system/default)
    defaultCategories.forEach(cat => {
      const id = this.currentIds.category++;
      const category: Category = {
        id,
        userId: 0,
        name: cat.name!,
        color: cat.color || '#000000',
        icon: cat.icon || 'circle',
        isDefault: true
      };
      this.categories.set(id, category);
    });
  }

  private createDefaultCategoriesForUser(userId: number) {
    // Get all default categories
    const defaultCategories = Array.from(this.categories.values())
      .filter(cat => cat.isDefault);
    
    // Create a copy for the user
    defaultCategories.forEach(defCat => {
      const id = this.currentIds.category++;
      const category: Category = {
        ...defCat,
        id,
        userId,
        isDefault: false // User categories are not default
      };
      this.categories.set(id, category);
    });
  }
}

export class DatabaseStorage implements IStorage {
  public sessionStore: any;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    
    // Create default categories for this user
    await this.createDefaultCategoriesForUser(user.id);
    
    return user;
  }

  // Transaction operations
  async getTransactions(userId: number): Promise<Transaction[]> {
    return db.select().from(transactions).where(eq(transactions.userId, userId));
  }

  async getTransactionById(id: number): Promise<Transaction | undefined> {
    const [transaction] = await db.select().from(transactions).where(eq(transactions.id, id));
    return transaction;
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const now = new Date();
    const transactionData = {
      ...insertTransaction,
      date: insertTransaction.date || now
    };
    const [transaction] = await db.insert(transactions).values(transactionData).returning();
    return transaction;
  }

  async updateTransaction(id: number, updatedTransaction: Partial<InsertTransaction>): Promise<Transaction | undefined> {
    const [transaction] = await db
      .update(transactions)
      .set(updatedTransaction)
      .where(eq(transactions.id, id))
      .returning();
    return transaction;
  }

  async deleteTransaction(id: number): Promise<boolean> {
    const result = await db.delete(transactions).where(eq(transactions.id, id));
    return result.rowCount !== null && result.rowCount > 0;
  }

  // Category operations
  async getCategories(userId: number): Promise<Category[]> {
    return db
      .select()
      .from(categories)
      .where(
        or(
          eq(categories.userId, userId),
          eq(categories.isDefault, true)
        )
      );
  }

  async getCategoryById(id: number): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category;
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const [category] = await db.insert(categories).values(insertCategory).returning();
    return category;
  }

  async updateCategory(id: number, updatedCategory: Partial<InsertCategory>): Promise<Category | undefined> {
    const [existingCategory] = await db
      .select()
      .from(categories)
      .where(eq(categories.id, id));

    if (!existingCategory) return undefined;
    
    // Prevent modifying default categories
    if (existingCategory.isDefault) {
      throw new Error("Cannot modify default categories");
    }
    
    const [category] = await db
      .update(categories)
      .set(updatedCategory)
      .where(eq(categories.id, id))
      .returning();
    return category;
  }

  async deleteCategory(id: number): Promise<boolean> {
    const [category] = await db
      .select()
      .from(categories)
      .where(eq(categories.id, id));
      
    if (!category || category.isDefault) {
      return false;
    }
    
    const result = await db.delete(categories).where(eq(categories.id, id));
    return result.rowCount !== null && result.rowCount > 0;
  }

  // Budget operations
  async getBudgets(userId: number): Promise<Budget[]> {
    return db.select().from(budgets).where(eq(budgets.userId, userId));
  }

  async getBudgetById(id: number): Promise<Budget | undefined> {
    const [budget] = await db.select().from(budgets).where(eq(budgets.id, id));
    return budget;
  }

  async createBudget(insertBudget: InsertBudget): Promise<Budget> {
    const [budget] = await db.insert(budgets).values(insertBudget).returning();
    return budget;
  }

  async updateBudget(id: number, updatedBudget: Partial<InsertBudget>): Promise<Budget | undefined> {
    const [budget] = await db
      .update(budgets)
      .set(updatedBudget)
      .where(eq(budgets.id, id))
      .returning();
    return budget;
  }

  async deleteBudget(id: number): Promise<boolean> {
    const result = await db.delete(budgets).where(eq(budgets.id, id));
    return result.rowCount !== null && result.rowCount > 0;
  }

  // Bill operations
  async getBills(userId: number): Promise<Bill[]> {
    return db.select().from(bills).where(eq(bills.userId, userId));
  }

  async getBillById(id: number): Promise<Bill | undefined> {
    const [bill] = await db.select().from(bills).where(eq(bills.id, id));
    return bill;
  }

  async createBill(insertBill: InsertBill): Promise<Bill> {
    const [bill] = await db.insert(bills).values(insertBill).returning();
    return bill;
  }

  async updateBill(id: number, updatedBill: Partial<InsertBill>): Promise<Bill | undefined> {
    const [bill] = await db
      .update(bills)
      .set(updatedBill)
      .where(eq(bills.id, id))
      .returning();
    return bill;
  }

  async deleteBill(id: number): Promise<boolean> {
    const result = await db.delete(bills).where(eq(bills.id, id));
    return result.rowCount !== null && result.rowCount > 0;
  }

  // Helper methods
  private async createDefaultCategoriesForUser(userId: number) {
    const defaultCategories: Partial<Category>[] = [
      { name: 'Housing', color: '#3B82F6', icon: 'building' },
      { name: 'Food & Dining', color: '#10B981', icon: 'restaurant' },
      { name: 'Transportation', color: '#F59E0B', icon: 'gas-station' },
      { name: 'Entertainment', color: '#EF4444', icon: 'film' },
      { name: 'Utilities', color: '#6366F1', icon: 'plug' },
      { name: 'Healthcare', color: '#EC4899', icon: 'first-aid' },
      { name: 'Shopping', color: '#8B5CF6', icon: 'shopping-bag' },
      { name: 'Personal', color: '#14B8A6', icon: 'user' },
      { name: 'Education', color: '#F97316', icon: 'graduation-cap' },
      { name: 'Income', color: '#22C55E', icon: 'bank' }
    ];
    
    // Create user categories - only the categories, no sample data
    for (const cat of defaultCategories) {
      await db.insert(categories).values({
        userId,
        name: cat.name!,
        color: cat.color || '#000000',
        icon: cat.icon || 'circle',
        isDefault: false
      }).returning();
    }
    
    // No sample data will be created for new user accounts
  }
}

// Export the database storage implementation
export const storage = new DatabaseStorage();
