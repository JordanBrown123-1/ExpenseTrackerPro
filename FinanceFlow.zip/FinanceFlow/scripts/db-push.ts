import { drizzle } from "drizzle-orm/neon-serverless";
import { Pool, neonConfig } from "@neondatabase/serverless";
import { migrate } from "drizzle-orm/neon-serverless/migrator";
import ws from "ws";
import * as schema from "../shared/schema";
import * as fs from "fs";
import * as path from "path";

// Required for Neon serverless
neonConfig.webSocketConstructor = ws;

async function main() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL environment variable is not set");
  }

  console.log("Connecting to database...");
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const db = drizzle(pool, { schema });

  console.log("Running migrations...");
  
  try {
    // Get migration files from migrations directory
    const migrationsDir = path.join(process.cwd(), "migrations");
    if (!fs.existsSync(migrationsDir)) {
      throw new Error(`Migrations directory not found: ${migrationsDir}`);
    }
    
    const migrationFiles = fs.readdirSync(migrationsDir)
      .filter(file => file.endsWith('.sql'))
      .map(file => path.join(migrationsDir, file));
    
    console.log(`Found ${migrationFiles.length} migration files`);
    
    // Execute each SQL file directly
    for (const file of migrationFiles) {
      console.log(`Executing migration: ${path.basename(file)}`);
      const sql = fs.readFileSync(file, 'utf-8');
      
      // Split the SQL by statement-breakpoint
      const statements = sql.split('--> statement-breakpoint')
        .map(stmt => stmt.trim())
        .filter(stmt => stmt);
      
      for (const statement of statements) {
        try {
          await pool.query(statement);
          console.log("SQL statement executed successfully");
        } catch (err) {
          // If table already exists, continue
          if (err.message.includes('already exists')) {
            console.log("Table already exists, skipping");
          } else {
            throw err;
          }
        }
      }
    }
    
    console.log("Migrations completed successfully!");
  } catch (error) {
    console.error("Error running migrations:", error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

main();