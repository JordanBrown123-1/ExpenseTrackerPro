import { drizzle } from "drizzle-orm/neon-serverless";
import { Pool, neonConfig } from "@neondatabase/serverless";
import ws from "ws";
import * as schema from "../shared/schema";

// Required for Neon serverless
neonConfig.webSocketConstructor = ws;

async function main() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL environment variable is not set");
  }

  console.log("Connecting to database...");
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const db = drizzle(pool, { schema });

  try {
    // Test query to list all tables
    const tables = await pool.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
    `);
    
    console.log("Available tables:");
    tables.rows.forEach((row) => {
      console.log(`- ${row.table_name}`);
    });
    
    // Get the count of records in each table
    for (const table of tables.rows) {
      const countResult = await pool.query(`SELECT COUNT(*) FROM "${table.table_name}"`);
      console.log(`${table.table_name}: ${countResult.rows[0].count} records`);
    }
    
  } catch (error) {
    console.error("Error testing database connection:", error);
  } finally {
    await pool.end();
  }
}

main();