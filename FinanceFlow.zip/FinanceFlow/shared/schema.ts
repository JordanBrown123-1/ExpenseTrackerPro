import { pgTable, text, serial, integer, boolean, timestamp, real, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  email: text("email"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
});

// Transaction schema
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: doublePrecision("amount").notNull(),
  type: text("type").notNull(), // 'income' or 'expense'
  categoryId: integer("category_id").notNull(),
  date: timestamp("date").notNull().defaultNow(),
  description: text("description"),
  notes: text("notes"),
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  userId: true,
  amount: true,
  type: true,
  categoryId: true,
  date: true,
  description: true,
  notes: true,
});

// Category schema
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  color: text("color"),
  icon: text("icon"),
  isDefault: boolean("is_default").default(false),
});

export const insertCategorySchema = createInsertSchema(categories).pick({
  userId: true,
  name: true,
  color: true,
  icon: true,
  isDefault: true,
});

// Budget schema
export const budgets = pgTable("budgets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  categoryId: integer("category_id").notNull(),
  amount: doublePrecision("amount").notNull(),
  period: text("period").notNull(), // 'monthly', 'weekly', etc.
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
});

export const insertBudgetSchema = createInsertSchema(budgets, {
  startDate: z.coerce.date(),
  endDate: z.coerce.date().nullable().optional(),
}).pick({
  userId: true,
  categoryId: true,
  amount: true,
  period: true,
  startDate: true,
  endDate: true,
});

// Bills schema
export const bills = pgTable("bills", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  amount: doublePrecision("amount").notNull(),
  dueDate: timestamp("due_date").notNull(),
  frequency: text("frequency").notNull(), // 'monthly', 'weekly', etc.
  categoryId: integer("category_id"),
  paid: boolean("paid").default(false),
});

export const insertBillSchema = createInsertSchema(bills).pick({
  userId: true,
  name: true,
  amount: true,
  dueDate: true,
  frequency: true,
  categoryId: true,
  paid: true,
});

// Type definitions
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;

export type Budget = typeof budgets.$inferSelect;
export type InsertBudget = z.infer<typeof insertBudgetSchema>;

export type Bill = typeof bills.$inferSelect;
export type InsertBill = z.infer<typeof insertBillSchema>;

// Extended schemas for frontend validation
export const transactionFormSchema = insertTransactionSchema
  .omit({ userId: true }) // Remove userId from form schema
  .extend({
    amount: z.coerce.number().positive(),
    date: z.coerce.date(),
    categoryId: z.coerce.number().int(),
  });

export const categoryFormSchema = insertCategorySchema.extend({
  name: z.string().min(1, "Category name is required"),
  color: z.string(),
  icon: z.string(),
});

export const budgetFormSchema = insertBudgetSchema.extend({
  amount: z.coerce.number().positive(),
  startDate: z.coerce.date(),
  endDate: z.coerce.date().optional(),
});

export const billFormSchema = insertBillSchema.extend({
  amount: z.coerce.number().positive(),
  dueDate: z.coerce.date(),
});
