// Test file to check imports
import BillsPage from "@/pages/bills";
import BudgetPage from "@/pages/budget-page";

// This file is just to test if TypeScript can find the imports correctly
console.log("Import test file");