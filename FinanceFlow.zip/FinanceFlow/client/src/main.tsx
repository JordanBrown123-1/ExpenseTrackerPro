import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Initialize Chart.js if needed
import { Chart, CategoryScale, LinearScale, BarElement, PointElement, LineElement, ArcElement, Tooltip, Legend } from "chart.js";

Chart.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  ArcElement,
  Tooltip,
  Legend
);

createRoot(document.getElementById("root")!).render(<App />);
