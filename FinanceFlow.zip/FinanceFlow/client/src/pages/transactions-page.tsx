import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { DashboardHeader } from "@/components/layout/dashboard-header";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Transaction, Category } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Card, 
  CardContent, 
  CardHeader,
  CardTitle,
  CardDescription
} from "@/components/ui/card";
import { TransactionModal } from "@/components/ui/transaction-modal";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Search, Calendar as CalendarIcon, Edit, Trash2, Building, Banknote, Utensils, Fuel, Film, Plus, Download } from "lucide-react";
import { exportTransactionsToCSV } from "@/lib/export-utils";

// Helper to get category icon
const getCategoryIcon = (iconName: string, className: string = "h-4 w-4") => {
  switch (iconName) {
    case 'building': return <Building className={className} />;
    case 'bank': return <Banknote className={className} />;
    case 'restaurant': return <Utensils className={className} />;
    case 'gas-station': return <Fuel className={className} />;
    case 'film': return <Film className={className} />;
    default: return <Building className={className} />;
  }
};

export default function TransactionsPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<"all" | "income" | "expense">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [dateFilter, setDateFilter] = useState<Date | undefined>(undefined);
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [transactionToDelete, setTransactionToDelete] = useState<Transaction | null>(null);

  // Fetch transactions data
  const { data: transactions, isLoading: isLoadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  // Fetch categories for displaying transaction category badges
  const { data: categories, isLoading: isLoadingCategories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  // Delete transaction mutation
  const deleteTransactionMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/transactions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      toast({
        title: "Transaction deleted",
        description: "The transaction has been successfully deleted.",
      });
      setTransactionToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete transaction",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Helper to get category name by ID
  const getCategoryName = (categoryId: number) => {
    const category = categories?.find(c => c.id === categoryId);
    return category?.name || "Uncategorized";
  };

  // Helper to get badge style based on transaction type and category
  const getTransactionBadgeStyle = (categoryId: number, type: string) => {
    if (type === 'income') {
      return "bg-green-100 text-green-800";
    }
    
    const colorMap: Record<string, string> = {
      "Housing": "bg-blue-100 text-blue-800",
      "Food & Dining": "bg-green-100 text-green-800",
      "Transportation": "bg-amber-100 text-amber-800",
      "Entertainment": "bg-red-100 text-red-800",
      "Utilities": "bg-indigo-100 text-indigo-800",
      "Healthcare": "bg-pink-100 text-pink-800",
      "Shopping": "bg-purple-100 text-purple-800",
      "Education": "bg-orange-100 text-orange-800",
      "Personal": "bg-teal-100 text-teal-800",
    };
    
    const categoryName = getCategoryName(categoryId);
    return colorMap[categoryName] || "bg-gray-100 text-gray-800";
  };

  // Filter transactions based on active filter, search query, and date
  const filteredTransactions = transactions?.filter(transaction => {
    // Apply tab filter
    if (activeTab !== "all" && transaction.type !== activeTab) {
      return false;
    }
    
    // Apply search filter
    if (searchQuery && !transaction.description?.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    // Apply date filter
    if (dateFilter) {
      const transactionDate = new Date(transaction.date);
      return (
        transactionDate.getFullYear() === dateFilter.getFullYear() &&
        transactionDate.getMonth() === dateFilter.getMonth() &&
        transactionDate.getDate() === dateFilter.getDate()
      );
    }
    
    return true;
  }) || [];

  // Handle edit transaction
  const handleEditTransaction = (transaction: Transaction) => {
    setSelectedTransaction(transaction);
    setIsTransactionModalOpen(true);
  };

  // Handle opening transaction modal with appropriate type based on current tab
  const handleOpenTransactionModal = () => {
    if (activeTab === "income") {
      setSelectedTransaction({ type: "income" } as Transaction);
    } else if (activeTab === "expense") {
      setSelectedTransaction({ type: "expense" } as Transaction);
    } else {
      setSelectedTransaction(null);
    }
    setIsTransactionModalOpen(true);
  };

  // Handle transaction modal close
  const handleTransactionModalClose = () => {
    setIsTransactionModalOpen(false);
    setSelectedTransaction(null);
  };

  // Handle delete transaction
  const handleDeleteTransaction = (transaction: Transaction) => {
    setTransactionToDelete(transaction);
  };
  
  // Handle export transactions to CSV
  const handleExportTransactions = () => {
    if (transactions && categories) {
      // Use current filtered transactions instead of all transactions
      const dataToExport = filteredTransactions.length > 0 ? filteredTransactions : transactions;
      exportTransactionsToCSV(dataToExport, categories);
      
      toast({
        title: "Export successful",
        description: "Your transactions have been exported as a CSV file.",
      });
    } else {
      toast({
        title: "Export failed",
        description: "There are no transactions to export.",
        variant: "destructive",
      });
    }
  };

  // Confirm delete transaction
  const confirmDeleteTransaction = () => {
    if (transactionToDelete) {
      deleteTransactionMutation.mutate(transactionToDelete.id);
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <div className="p-4 md:p-6 max-w-7xl mx-auto">
          <DashboardHeader title="Transactions" showBackButton={true} />
          
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <CardTitle>Transaction History</CardTitle>
                  <CardDescription>View and manage all your income and expenses</CardDescription>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-2">
                  {/* Add Transaction Button */}
                  <Button 
                    className="w-full sm:w-auto mb-2 sm:mb-0 sm:order-last"
                    onClick={handleOpenTransactionModal}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Transaction
                  </Button>
                  
                  {/* Export Button */}
                  <Button
                    variant="outline"
                    className="w-full sm:w-auto mb-2 sm:mb-0"
                    onClick={() => handleExportTransactions()}
                    disabled={!transactions || transactions.length === 0}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Export CSV
                  </Button>
                  
                  {/* Search Box */}
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                    <Input
                      placeholder="Search transactions..."
                      className="pl-8 w-full sm:w-[200px]"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  
                  {/* Date Filter */}
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="gap-2">
                        <CalendarIcon className="h-4 w-4" />
                        {dateFilter ? format(dateFilter, "PPP") : "Filter by date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={dateFilter}
                        onSelect={setDateFilter}
                        initialFocus
                      />
                      {dateFilter && (
                        <div className="p-3 border-t">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => setDateFilter(undefined)}
                            className="w-full"
                          >
                            Clear date filter
                          </Button>
                        </div>
                      )}
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              <Tabs defaultValue="all" onValueChange={(value) => setActiveTab(value as "all" | "income" | "expense")}>
                <TabsList className="mb-4">
                  <TabsTrigger value="all">All Transactions</TabsTrigger>
                  <TabsTrigger value="income">Income</TabsTrigger>
                  <TabsTrigger value="expense">Expenses</TabsTrigger>
                </TabsList>
                
                <TabsContent value="all" className="space-y-4">
                  {renderTransactionsTable()}
                </TabsContent>
                <TabsContent value="income" className="space-y-4">
                  {renderTransactionsTable()}
                </TabsContent>
                <TabsContent value="expense" className="space-y-4">
                  {renderTransactionsTable()}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
          
          {/* Transaction Modal */}
          {isTransactionModalOpen && (
            <TransactionModal 
              isOpen={isTransactionModalOpen}
              onClose={handleTransactionModalClose}
              categories={categories || []}
              transaction={selectedTransaction}
            />
          )}
          
          {/* Delete Confirmation Dialog */}
          <AlertDialog open={!!transactionToDelete} onOpenChange={(open) => !open && setTransactionToDelete(null)}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete the transaction
                  from your account.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={confirmDeleteTransaction}>
                  {deleteTransactionMutation.isPending ? "Deleting..." : "Delete"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </main>
    </div>
  );

  // Helper to render transactions table
  function renderTransactionsTable() {
    if (isLoadingTransactions || isLoadingCategories) {
      return (
        <div className="space-y-4">
          {Array(5).fill(0).map((_, i) => (
            <div key={i} className="flex items-center space-x-4 p-4 border rounded-lg">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-1/3" />
                <Skeleton className="h-3 w-1/4" />
              </div>
              <Skeleton className="h-4 w-20" />
            </div>
          ))}
        </div>
      );
    }

    if (filteredTransactions.length === 0) {
      return (
        <div className="text-center py-10">
          <p className="text-gray-500">No transactions found.</p>
          <Button 
            variant="outline" 
            className="mt-4"
            onClick={handleOpenTransactionModal}
          >
            Add a new transaction
          </Button>
        </div>
      );
    }

    return (
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Description</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Date</TableHead>
              <TableHead className="text-right">Amount</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredTransactions.map((transaction) => (
              <TableRow key={transaction.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <span className={`p-2 rounded-full ${
                      transaction.type === 'income' 
                        ? 'bg-green-50 text-green-500' 
                        : 'bg-gray-50 text-gray-500'
                    }`}>
                      {getCategoryIcon(
                        categories?.find(c => c.id === transaction.categoryId)?.icon || 'building'
                      )}
                    </span>
                    <div>
                      <div className="font-medium">
                        {transaction.description || (transaction.type === 'income' ? 'Income' : 'Expense')}
                      </div>
                      {transaction.notes && (
                        <div className="text-sm text-gray-500">{transaction.notes}</div>
                      )}
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge className={getTransactionBadgeStyle(transaction.categoryId, transaction.type)}>
                    {getCategoryName(transaction.categoryId)}
                  </Badge>
                </TableCell>
                <TableCell>{format(new Date(transaction.date), 'MMM dd, yyyy')}</TableCell>
                <TableCell className={`text-right font-mono font-medium ${
                  transaction.type === 'income' ? 'text-success-500' : 'text-danger-500'
                }`}>
                  {transaction.type === 'income' ? '+' : '-'}
                  ${transaction.amount.toFixed(2)}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEditTransaction(transaction)}
                    >
                      <Edit className="h-4 w-4" />
                      <span className="sr-only">Edit</span>
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteTransaction(transaction)}
                    >
                      <Trash2 className="h-4 w-4" />
                      <span className="sr-only">Delete</span>
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    );
  }
}
