import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { DashboardHeader } from "@/components/layout/dashboard-header";
import { SummaryCard } from "@/components/ui/summary-card";
import { SpendingChart } from "@/components/ui/spending-chart";
import { CategoryChart, CategoryList } from "@/components/ui/category-chart";
import { BudgetCard } from "@/components/ui/budget-card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Transaction, Category } from "@shared/schema";
import { format } from "date-fns";
import { 
  Plus, 
  Building, 
  Banknote, 
  Utensils, 
  Fuel, 
  Film, 
  Wifi, 
  CreditCard, 
  Smartphone, 
  Settings,
  Calendar
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";

// Helper to get category icon
const getCategoryIcon = (iconName: string, className: string = "h-4 w-4") => {
  switch (iconName) {
    case 'building': return <Building className={className} />;
    case 'bank': return <Banknote className={className} />;
    case 'restaurant': return <Utensils className={className} />;
    case 'gas-station': return <Fuel className={className} />;
    case 'film': return <Film className={className} />;
    case 'wifi': return <Wifi className={className} />;
    case 'credit-card': return <CreditCard className={className} />;
    case 'smartphone': return <Smartphone className={className} />;
    default: return <Building className={className} />;
  }
};

// Type for summary data
export type SummaryData = {
  summary: {
    income: number;
    expenses: number;
    balance: number;
    incomeChange: number;
    expenseChange: number;
    budgetStatus: number;
  };
  categorySpending: {
    id: number;
    name: string;
    color: string;
    icon: string;
    amount: number;
    percentage: number;
  }[];
  monthlyData: {
    month: string;
    income: number;
    expenses: number;
  }[];
  upcomingBills: {
    id: number;
    name: string;
    amount: number;
    dueDate: string;
    frequency: string;
    categoryId: number;
    paid: boolean;
  }[];
  budgetProgress: {
    id: number;
    categoryId: number;
    categoryName: string;
    amount: number;
    spent: number;
    percentage: number;
  }[];
  recentTransactions: Transaction[];
};

export default function DashboardPage() {
  const [activeTransactionFilter, setActiveTransactionFilter] = useState<"all" | "income" | "expense">("all");
  const [timeRange, setTimeRange] = useState<"1" | "3" | "6">("6"); // Default to 6 months
  const [categoryTimeRange, setCategoryTimeRange] = useState<"1" | "3" | "6">("1"); // Default to current month
  
  // Fetch dashboard summary data
  const { data: summaryData, isLoading: isLoadingSummary } = useQuery<SummaryData>({
    queryKey: ["/api/summary", { timeRange, categoryTimeRange }],
    queryFn: ({ queryKey }) => {
      const [url, params] = queryKey;
      const { timeRange, categoryTimeRange } = params as { timeRange: string, categoryTimeRange: string };
      return fetch(`${url}?timeRange=${timeRange}&categoryTimeRange=${categoryTimeRange}`).then(res => {
        if (!res.ok) throw new Error('Failed to fetch summary data');
        return res.json();
      });
    }
  });
  
  // Fetch categories for displaying transaction category badges
  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Helper to get category name by ID
  const getCategoryName = (categoryId: number) => {
    const category = categories?.find(c => c.id === categoryId);
    return category?.name || "Uncategorized";
  };
  
  // Helper to get category color by ID
  const getCategoryColor = (categoryId: number) => {
    const category = categories?.find(c => c.id === categoryId);
    return category?.color || "#000000";
  };
  
  // Helper to get badge style based on transaction type
  const getTransactionBadgeStyle = (categoryId: number, type: string) => {
    const color = getCategoryColor(categoryId);
    
    if (type === 'income') {
      return "bg-green-100 text-green-800";
    }
    
    // TODO: Generate badge style based on category color
    const colorMap: Record<string, string> = {
      "#3B82F6": "bg-blue-100 text-blue-800",
      "#10B981": "bg-green-100 text-green-800",
      "#F59E0B": "bg-amber-100 text-amber-800",
      "#EF4444": "bg-red-100 text-red-800",
      "#6366F1": "bg-indigo-100 text-indigo-800",
      "#8B5CF6": "bg-purple-100 text-purple-800",
      "#EC4899": "bg-pink-100 text-pink-800",
      "#F97316": "bg-orange-100 text-orange-800",
    };
    
    return colorMap[color] || "bg-gray-100 text-gray-800";
  };

  // Filter transactions based on active filter
  const filteredTransactions = summaryData?.recentTransactions.filter(transaction => {
    if (activeTransactionFilter === "all") return true;
    return transaction.type === activeTransactionFilter;
  }) || [];

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <div className="p-4 md:p-6 max-w-7xl mx-auto">
          <DashboardHeader 
            title="Financial Dashboard" 
            summaryData={summaryData}
          />
          
          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {isLoadingSummary ? (
              // Loading skeletons
              Array(4).fill(0).map((_, i) => (
                <div key={i} className="bg-white rounded-xl shadow-sm p-5 border border-gray-100 space-y-4">
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-5 w-32" />
                    <Skeleton className="h-10 w-10 rounded-lg" />
                  </div>
                  <Skeleton className="h-8 w-24" />
                  <Skeleton className="h-4 w-40" />
                </div>
              ))
            ) : (
              <>
                <SummaryCard
                  title="Monthly Income"
                  amount={summaryData?.summary.income || 0}
                  type="income"
                  change={summaryData?.summary.incomeChange}
                />
                <SummaryCard
                  title="Monthly Expenses"
                  amount={summaryData?.summary.expenses || 0}
                  type="expense"
                  change={summaryData?.summary.expenseChange}
                />
                <SummaryCard
                  title="Balance"
                  amount={summaryData?.summary.balance || 0}
                  type="balance"
                />
                <SummaryCard
                  title="Budget Status"
                  amount={0}
                  type="budget"
                  budgetStatus={summaryData?.summary.budgetStatus || 0}
                />
              </>
            )}
          </div>
          
          {/* Charts and Graphs */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            {/* Spending Overview Chart */}
            <div className="lg:col-span-2 bg-white rounded-xl p-5 shadow-sm border border-gray-100">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-800">Monthly Spending Overview</h3>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-1.5">
                      <Calendar className="h-4 w-4" />
                      {timeRange === "1" ? "Last month" : 
                       timeRange === "3" ? "Last 3 months" : 
                       "Last 6 months"}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem 
                      onClick={() => setTimeRange("1")}
                      className={timeRange === "1" ? "bg-primary-50 text-primary-600" : ""}
                    >
                      Last month
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => setTimeRange("3")}
                      className={timeRange === "3" ? "bg-primary-50 text-primary-600" : ""}
                    >
                      Last 3 months
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => setTimeRange("6")}
                      className={timeRange === "6" ? "bg-primary-50 text-primary-600" : ""}
                    >
                      Last 6 months
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              
              {isLoadingSummary ? (
                <Skeleton className="h-[300px] w-full" />
              ) : (
                <SpendingChart data={summaryData?.monthlyData || []} />
              )}
            </div>
            
            {/* Expense by Category */}
            <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-800">Expense by Category</h3>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-1.5">
                      <Calendar className="h-4 w-4" />
                      {categoryTimeRange === "1" ? "Last month" : 
                       categoryTimeRange === "3" ? "Last 3 months" : 
                       "Last 6 months"}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem 
                      onClick={() => setCategoryTimeRange("1")}
                      className={categoryTimeRange === "1" ? "bg-primary-50 text-primary-600" : ""}
                    >
                      Last month
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => setCategoryTimeRange("3")}
                      className={categoryTimeRange === "3" ? "bg-primary-50 text-primary-600" : ""}
                    >
                      Last 3 months
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => setCategoryTimeRange("6")}
                      className={categoryTimeRange === "6" ? "bg-primary-50 text-primary-600" : ""}
                    >
                      Last 6 months
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              
              {isLoadingSummary ? (
                <>
                  <Skeleton className="h-[200px] w-full" />
                  <div className="mt-4 space-y-2">
                    {Array(5).fill(0).map((_, i) => (
                      <div key={i} className="flex items-center justify-between">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-4 w-12" />
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <>
                  <CategoryChart data={summaryData?.categorySpending || []} />
                  <CategoryList data={summaryData?.categorySpending || []} />
                </>
              )}
            </div>
          </div>
          
          {/* Recent Transactions & Upcoming Bills */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Recent Transactions */}
            <div className="lg:col-span-2 bg-white rounded-xl p-5 shadow-sm border border-gray-100">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-800">Recent Transactions</h3>
                <Link to="/transactions">
                  <Button variant="link" size="sm" className="text-primary-500">
                    View All
                  </Button>
                </Link>
              </div>
              
              {/* Transaction Filters */}
              <div className="flex flex-wrap gap-2 mb-4">
                <Button
                  variant="ghost"
                  size="sm"
                  className={`rounded-full ${activeTransactionFilter === "all" ? "bg-primary-50 text-primary-600" : ""}`}
                  onClick={() => setActiveTransactionFilter("all")}
                >
                  All
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className={`rounded-full ${activeTransactionFilter === "income" ? "bg-primary-50 text-primary-600" : ""}`}
                  onClick={() => setActiveTransactionFilter("income")}
                >
                  Income
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className={`rounded-full ${activeTransactionFilter === "expense" ? "bg-primary-50 text-primary-600" : ""}`}
                  onClick={() => setActiveTransactionFilter("expense")}
                >
                  Expense
                </Button>
              </div>
              
              {/* Transaction List */}
              <div className="overflow-x-auto -mx-5">
                <table className="w-full min-w-full table-auto">
                  <thead>
                    <tr className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      <th className="px-5 py-3">Description</th>
                      <th className="px-5 py-3">Category</th>
                      <th className="px-5 py-3">Date</th>
                      <th className="px-5 py-3 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {isLoadingSummary ? (
                      Array(5).fill(0).map((_, i) => (
                        <tr key={i}>
                          <td className="px-5 py-4">
                            <div className="flex items-center">
                              <Skeleton className="h-10 w-10 rounded-full mr-3" />
                              <div>
                                <Skeleton className="h-4 w-32 mb-1" />
                                <Skeleton className="h-3 w-24" />
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-4"><Skeleton className="h-5 w-20" /></td>
                          <td className="px-5 py-4"><Skeleton className="h-4 w-24" /></td>
                          <td className="px-5 py-4 text-right"><Skeleton className="h-4 w-20 ml-auto" /></td>
                        </tr>
                      ))
                    ) : filteredTransactions.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-5 py-8 text-center text-gray-500">
                          No transactions found
                        </td>
                      </tr>
                    ) : (
                      filteredTransactions.map((transaction) => (
                        <tr key={transaction.id} className="hover:bg-gray-50">
                          <td className="px-5 py-4">
                            <div className="flex items-center">
                              <span className={`p-2 mr-3 rounded-full ${
                                transaction.type === 'income' 
                                  ? 'bg-green-50 text-green-500' 
                                  : `bg-${getCategoryColor(transaction.categoryId).replace('#', '')}-50`
                              }`}>
                                {getCategoryIcon(
                                  categories?.find(c => c.id === transaction.categoryId)?.icon || 'building'
                                )}
                              </span>
                              <div>
                                <div className="font-medium text-gray-800">
                                  {transaction.description || (transaction.type === 'income' ? 'Income' : 'Expense')}
                                </div>
                                <div className="text-gray-500 text-xs">
                                  {transaction.notes || (
                                    transaction.type === 'income' 
                                      ? 'Income transaction' 
                                      : `${getCategoryName(transaction.categoryId)} expense`
                                  )}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-4">
                            <Badge className={getTransactionBadgeStyle(transaction.categoryId, transaction.type)}>
                              {getCategoryName(transaction.categoryId)}
                            </Badge>
                          </td>
                          <td className="px-5 py-4 text-sm text-gray-500">
                            {format(new Date(transaction.date), 'MMM dd, yyyy')}
                          </td>
                          <td className={`px-5 py-4 text-right font-mono font-medium ${
                            transaction.type === 'income' ? 'text-success-500' : 'text-danger-500'
                          }`}>
                            {transaction.type === 'income' ? '+' : '-'}
                            ${transaction.amount.toFixed(2)}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
            
            {/* Sidebar: Upcoming Bills & Budget Progress */}
            <div className="space-y-6">
              {/* Upcoming Bills */}
              <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-gray-800">Upcoming Bills</h3>
                  <Link to="/bills">
                    <Button variant="link" size="sm" className="text-primary-500">
                      View All
                    </Button>
                  </Link>
                </div>
                
                {isLoadingSummary ? (
                  <div className="space-y-3">
                    {Array(3).fill(0).map((_, i) => (
                      <div key={i} className="flex items-center justify-between pb-3 border-b border-gray-100">
                        <div className="flex items-center">
                          <Skeleton className="h-10 w-10 rounded-full mr-3" />
                          <div>
                            <Skeleton className="h-4 w-24 mb-1" />
                            <Skeleton className="h-3 w-16" />
                          </div>
                        </div>
                        <Skeleton className="h-4 w-16" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-3">
                    {summaryData?.upcomingBills.map((bill) => {
                      const daysUntilDue = Math.ceil(
                        (new Date(bill.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
                      );
                      
                      return (
                        <div key={bill.id} className="flex items-center justify-between pb-3 border-b border-gray-100">
                          <div className="flex items-center">
                            <span className="p-2 mr-3 rounded-full bg-red-50 text-red-500">
                              <Wifi className="h-4 w-4" />
                            </span>
                            <div>
                              <div className="font-medium text-gray-800">{bill.name}</div>
                              <div className="text-xs text-gray-500">
                                {daysUntilDue <= 0 
                                  ? 'Due today' 
                                  : `Due in ${daysUntilDue} ${daysUntilDue === 1 ? 'day' : 'days'}`}
                              </div>
                            </div>
                          </div>
                          <span className="font-mono font-medium text-gray-800">${bill.amount.toFixed(2)}</span>
                        </div>
                      );
                    })}
                    
                    {(!summaryData?.upcomingBills || summaryData.upcomingBills.length === 0) && (
                      <div className="text-center py-3 text-gray-500">No upcoming bills</div>
                    )}
                  </div>
                )}
                
                <Link to="/bills">
                  <Button variant="outline" className="w-full mt-4" size="sm">
                    <Plus className="h-4 w-4 mr-1" />
                    Add New Bill
                  </Button>
                </Link>
              </div>
              
              {/* Budget Progress */}
              <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-gray-800">Budget Progress</h3>
                  <Link to="/budgets">
                    <Button variant="ghost" size="sm" className="p-1">
                      <Settings className="h-4 w-4" />
                    </Button>
                  </Link>
                </div>
                
                {isLoadingSummary ? (
                  <div className="space-y-4">
                    {Array(3).fill(0).map((_, i) => (
                      <div key={i}>
                        <div className="flex items-center justify-between mb-1.5">
                          <Skeleton className="h-4 w-32" />
                          <Skeleton className="h-4 w-12" />
                        </div>
                        <Skeleton className="h-2 w-full rounded-full" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {summaryData?.budgetProgress && summaryData.budgetProgress.length > 0 ? (
                      summaryData.budgetProgress.map((budget) => (
                        <BudgetCard
                          key={budget.id}
                          categoryName={budget.categoryName}
                          spent={budget.spent}
                          amount={budget.amount}
                          percentage={budget.percentage}
                        />
                      ))
                    ) : (
                      <div className="text-center py-3 text-gray-500">No budgets set</div>
                    )}
                  </div>
                )}
                
                <Link to="/budgets">
                  <Button variant="outline" className="w-full mt-4" size="sm">
                    <Plus className="h-4 w-4 mr-1" />
                    Create New Budget
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
