import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Sidebar } from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Plus, Calendar, Edit2, Trash2, CalendarCheck } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { format, isAfter, isBefore, addDays } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Bill, Category, insertBillSchema } from "@shared/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { z } from "zod";

// Form schema
const billFormSchema = insertBillSchema
  .omit({ userId: true })
  .extend({
    dueDate: z.date({
      required_error: "Due date is required",
    }),
  });

type BillFormValues = z.infer<typeof billFormSchema>;

export default function BillsPage() {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingBill, setEditingBill] = useState<Bill | null>(null);
  const [billToDelete, setBillToDelete] = useState<Bill | null>(null);
  const { toast } = useToast();
  
  // Fetch bills
  const { data: bills, isLoading: isLoadingBills } = useQuery<Bill[]>({
    queryKey: ["/api/bills"],
  });
  
  // Fetch categories for the form
  const { data: categories, isLoading: isLoadingCategories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Setup form
  const form = useForm<BillFormValues>({
    resolver: zodResolver(billFormSchema),
    defaultValues: {
      name: "",
      amount: 0,
      categoryId: 0,
      dueDate: new Date(),
      frequency: "monthly",
      paid: false,
    },
  });
  
  // Create bill mutation
  const createBillMutation = useMutation({
    mutationFn: async (data: BillFormValues) => {
      const response = await apiRequest("POST", "/api/bills", data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bills"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      toast({
        title: "Bill created",
        description: "Your bill has been created successfully.",
      });
      closeDialog();
    },
    onError: (error: Error) => {
      toast({
        title: "Error creating bill",
        description: error.message || "Failed to create bill",
        variant: "destructive",
      });
    },
  });
  
  // Update bill mutation
  const updateBillMutation = useMutation({
    mutationFn: async ({ id, values }: { id: number; values: BillFormValues }) => {
      const response = await apiRequest("PUT", `/api/bills/${id}`, values);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bills"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      toast({
        title: "Bill updated",
        description: "Your bill has been updated successfully.",
      });
      closeDialog();
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating bill",
        description: error.message || "Failed to update bill",
        variant: "destructive",
      });
    },
  });
  
  // Delete bill mutation
  const deleteBillMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/bills/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bills"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      toast({
        title: "Bill deleted",
        description: "Your bill has been deleted successfully.",
      });
      setBillToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error deleting bill",
        description: error.message || "Failed to delete bill",
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (values: BillFormValues) => {
    if (editingBill) {
      updateBillMutation.mutate({ id: editingBill.id, values });
    } else {
      createBillMutation.mutate(values);
    }
  };
  
  // Handle edit bill
  const handleEditBill = (bill: Bill) => {
    setEditingBill(bill);
    form.reset({
      name: bill.name,
      amount: bill.amount,
      categoryId: bill.categoryId,
      dueDate: new Date(bill.dueDate),
      frequency: bill.frequency,
      paid: bill.paid,
    });
    setIsAddDialogOpen(true);
  };
  
  // Handle delete bill
  const handleDeleteBill = (bill: Bill) => {
    setBillToDelete(bill);
  };
  
  // Confirm delete bill
  const confirmDeleteBill = () => {
    if (billToDelete) {
      deleteBillMutation.mutate(billToDelete.id);
    }
  };
  
  // Close dialog and reset form
  const closeDialog = () => {
    setIsAddDialogOpen(false);
    setEditingBill(null);
    form.reset({
      name: "",
      amount: 0,
      categoryId: 0,
      dueDate: new Date(),
      frequency: "monthly",
      paid: false,
    });
  };
  
  // Get category name by ID
  const getCategoryName = (categoryId: number | null) => {
    if (categoryId === null) return "Unknown";
    const category = categories?.find(c => c.id === categoryId);
    return category?.name || "Unknown";
  };
  
  // Helper to get status badge
  const getBillStatusBadge = (bill: Bill) => {
    const dueDate = new Date(bill.dueDate);
    const today = new Date();
    
    if (bill.paid) {
      return <Badge className="bg-green-100 text-green-800">Paid</Badge>;
    }
    
    if (isAfter(today, dueDate)) {
      return <Badge className="bg-red-100 text-red-800">Overdue</Badge>;
    }
    
    if (isAfter(today, addDays(dueDate, -3))) {
      return <Badge className="bg-amber-100 text-amber-800">Due Soon</Badge>;
    }
    
    return <Badge className="bg-blue-100 text-blue-800">Upcoming</Badge>;
  };
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <div className="p-4 md:p-6 max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl md:text-2xl font-bold text-gray-800">Bills & Recurring Payments</h2>
            
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <Button onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add New Bill
              </Button>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingBill ? "Edit Bill" : "Add New Bill"}</DialogTitle>
                  <DialogDescription>
                    {editingBill 
                      ? "Update your bill details below." 
                      : "Enter the details of your bill or recurring payment."}
                  </DialogDescription>
                </DialogHeader>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bill Name</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Rent, Internet, etc." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Amount</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <span className="text-gray-500">$</span>
                              </div>
                              <Input 
                                placeholder="0.00" 
                                type="number" 
                                className="pl-8" 
                                {...field}
                                onChange={(e) => field.onChange(parseFloat(e.target.value))}
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="categoryId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select 
                            onValueChange={(value) => field.onChange(parseInt(value))}
                            value={field.value ? field.value.toString() : ""}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {categories?.filter(cat => cat.name !== "Income").map(category => (
                                <SelectItem key={category.id} value={category.id.toString()}>
                                  {category.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="dueDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Due Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className="pl-3 text-left font-normal"
                                >
                                  {field.value ? (
                                    format(field.value, "PPP")
                                  ) : (
                                    <span>Pick a date</span>
                                  )}
                                  <Calendar className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <CalendarComponent
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="frequency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Frequency</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select frequency" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="weekly">Weekly</SelectItem>
                              <SelectItem value="biweekly">Bi-weekly</SelectItem>
                              <SelectItem value="monthly">Monthly</SelectItem>
                              <SelectItem value="quarterly">Quarterly</SelectItem>
                              <SelectItem value="yearly">Yearly</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            How often this bill recurs.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="paid"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value === true}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Already paid</FormLabel>
                            <FormDescription>
                              Mark this bill as already paid for the current period.
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    <DialogFooter>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={closeDialog}
                      >
                        Cancel
                      </Button>
                      <Button type="submit" disabled={createBillMutation.isPending || updateBillMutation.isPending}>
                        {createBillMutation.isPending || updateBillMutation.isPending
                          ? "Saving..."
                          : editingBill
                          ? "Update Bill"
                          : "Add Bill"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Upcoming & Recent Bills</CardTitle>
              <CardDescription>
                Manage your recurring payments and bills
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingBills ? (
                <div className="space-y-4">
                  {Array(5).fill(0).map((_, i) => (
                    <div key={i} className="p-4 border rounded-lg">
                      <div className="flex justify-between mb-2">
                        <Skeleton className="h-5 w-1/3" />
                        <Skeleton className="h-5 w-16" />
                      </div>
                      <Skeleton className="h-4 w-full mb-2" />
                      <div className="flex justify-between">
                        <Skeleton className="h-4 w-1/4" />
                        <Skeleton className="h-4 w-1/4" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : bills && bills.length > 0 ? (
                <div className="space-y-4">
                  {bills.map(bill => (
                    <div key={bill.id} className="p-4 border rounded-lg">
                      <div className="flex justify-between mb-1">
                        <div>
                          <h3 className="font-semibold text-lg">{bill.name}</h3>
                          <p className="text-sm text-gray-500">{getCategoryName(bill.categoryId)}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-mono font-semibold text-lg">${bill.amount.toFixed(2)}</p>
                          {getBillStatusBadge(bill)}
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center mt-3 pt-2 border-t">
                        <div className="flex items-center gap-1 text-sm text-gray-600">
                          <CalendarCheck className="h-4 w-4" />
                          <span>Due: {format(new Date(bill.dueDate), "MMM dd, yyyy")}</span>
                          <span className="mx-1">•</span>
                          <span className="capitalize">{bill.frequency}</span>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditBill(bill)}
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteBill(bill)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <CalendarCheck className="mx-auto h-10 w-10 text-gray-400" />
                  <h3 className="mt-4 text-lg font-medium text-gray-900">No bills yet</h3>
                  <p className="mt-1 text-sm text-gray-500">Start by adding your recurring bills and payments.</p>
                  <div className="mt-6">
                    <Button onClick={() => setIsAddDialogOpen(true)}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Your First Bill
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!billToDelete} onOpenChange={(open) => !open && setBillToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the bill "{billToDelete?.name}". This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteBill}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}