import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Category, insertCategorySchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Plus, 
  Edit, 
  Trash2, 
  Tag,
  Building,
  Banknote,
  Utensils,
  Fuel,
  Film,
  Plug,
  ShoppingBag,
  UserRound,
  GraduationCap
} from "lucide-react";

// Category icons
const categoryIcons = [
  { value: "building", label: "Building", icon: <Building className="h-5 w-5" /> },
  { value: "bank", label: "Banknote", icon: <Banknote className="h-5 w-5" /> },
  { value: "restaurant", label: "Restaurant", icon: <Utensils className="h-5 w-5" /> },
  { value: "gas-station", label: "Gas Station", icon: <Fuel className="h-5 w-5" /> },
  { value: "film", label: "Entertainment", icon: <Film className="h-5 w-5" /> },
  { value: "plug", label: "Utilities", icon: <Plug className="h-5 w-5" /> },
  { value: "shopping-bag", label: "Shopping", icon: <ShoppingBag className="h-5 w-5" /> },
  { value: "user", label: "Personal", icon: <UserRound className="h-5 w-5" /> },
  { value: "graduation-cap", label: "Education", icon: <GraduationCap className="h-5 w-5" /> },
];

// Category colors
const categoryColors = [
  { value: "#3B82F6", label: "Blue" },
  { value: "#10B981", label: "Green" },
  { value: "#F59E0B", label: "Amber" },
  { value: "#EF4444", label: "Red" },
  { value: "#6366F1", label: "Indigo" },
  { value: "#8B5CF6", label: "Purple" },
  { value: "#EC4899", label: "Pink" },
  { value: "#F97316", label: "Orange" },
  { value: "#14B8A6", label: "Teal" },
];

// Form schema for category
const categoryFormSchema = z.object({
  name: z.string().min(1, "Category name is required"),
  color: z.string().default("#3B82F6"),
  icon: z.string().default("building"),
});

export default function CategoriesPage() {
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [categoryToDelete, setCategoryToDelete] = useState<Category | null>(null);
  
  // Get categories
  const { data: categories, isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Form for adding/editing category
  const form = useForm<z.infer<typeof categoryFormSchema>>({
    resolver: zodResolver(categoryFormSchema),
    defaultValues: {
      name: "",
      color: "#3B82F6",
      icon: "building",
    },
  });
  
  // Create category mutation
  const createCategoryMutation = useMutation({
    mutationFn: async (values: z.infer<typeof categoryFormSchema>) => {
      const res = await apiRequest("POST", "/api/categories", values);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      setIsAddDialogOpen(false);
      form.reset();
      toast({
        title: "Category created",
        description: "The category has been created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create category",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update category mutation
  const updateCategoryMutation = useMutation({
    mutationFn: async ({ id, values }: { id: number; values: z.infer<typeof categoryFormSchema> }) => {
      const res = await apiRequest("PUT", `/api/categories/${id}`, values);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      setIsAddDialogOpen(false);
      setEditingCategory(null);
      form.reset();
      toast({
        title: "Category updated",
        description: "The category has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update category",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete category mutation
  const deleteCategoryMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/categories/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      setCategoryToDelete(null);
      toast({
        title: "Category deleted",
        description: "The category has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete category",
        description: error.message || "System categories or categories in use cannot be deleted.",
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (values: z.infer<typeof categoryFormSchema>) => {
    if (editingCategory) {
      updateCategoryMutation.mutate({ id: editingCategory.id, values });
    } else {
      createCategoryMutation.mutate(values);
    }
  };
  
  // Handle edit category
  const handleEditCategory = (category: Category) => {
    setEditingCategory(category);
    form.reset({
      name: category.name,
      color: category.color || "#3B82F6",
      icon: category.icon || "building",
    });
    setIsAddDialogOpen(true);
  };
  
  // Handle delete category
  const handleDeleteCategory = (category: Category) => {
    setCategoryToDelete(category);
  };
  
  // Confirm delete category
  const confirmDeleteCategory = () => {
    if (categoryToDelete) {
      deleteCategoryMutation.mutate(categoryToDelete.id);
    }
  };
  
  // Close dialog and reset form
  const closeDialog = () => {
    setIsAddDialogOpen(false);
    setEditingCategory(null);
    form.reset();
  };

  // Get icon component by name
  const getIconByName = (iconName: string) => {
    const icon = categoryIcons.find(i => i.value === iconName);
    return icon ? icon.icon : <Tag className="h-5 w-5" />;
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <div className="p-4 md:p-6 max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <Button variant="outline" onClick={() => window.location.href = '/dashboard'}>
                Back to Dashboard
              </Button>
              <h2 className="text-xl md:text-2xl font-bold text-gray-800">Categories</h2>
            </div>
            
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Category
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingCategory ? "Edit Category" : "Add New Category"}</DialogTitle>
                  <DialogDescription>
                    {editingCategory 
                      ? "Update the category details below." 
                      : "Create a new category to organize your transactions."}
                  </DialogDescription>
                </DialogHeader>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category Name</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Groceries" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="icon"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Icon</FormLabel>
                          <div className="grid grid-cols-3 gap-2">
                            {categoryIcons.map((icon) => (
                              <Button
                                key={icon.value}
                                type="button"
                                variant={field.value === icon.value ? "default" : "outline"}
                                className="h-12 w-full"
                                onClick={() => form.setValue("icon", icon.value)}
                              >
                                {icon.icon}
                              </Button>
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="color"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Color</FormLabel>
                          <div className="grid grid-cols-3 gap-2">
                            {categoryColors.map((color) => (
                              <Button
                                key={color.value}
                                type="button"
                                variant="outline"
                                className="h-10 w-full flex justify-center items-center border-2"
                                style={{ 
                                  borderColor: field.value === color.value ? color.value : 'transparent',
                                  backgroundColor: field.value === color.value ? `${color.value}20` : 'transparent'
                                }}
                                onClick={() => form.setValue("color", color.value)}
                              >
                                <div 
                                  className="h-6 w-6 rounded-full" 
                                  style={{ backgroundColor: color.value }}
                                ></div>
                              </Button>
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <DialogFooter>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={closeDialog}
                      >
                        Cancel
                      </Button>
                      <Button type="submit" disabled={createCategoryMutation.isPending || updateCategoryMutation.isPending}>
                        {createCategoryMutation.isPending || updateCategoryMutation.isPending
                          ? "Saving..."
                          : editingCategory
                          ? "Update Category"
                          : "Add Category"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Manage Categories</CardTitle>
              <CardDescription>
                Organize your expenses into categories for better financial tracking
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {Array(5).fill(0).map((_, i) => (
                    <div key={i} className="flex items-center space-x-4 p-4 border rounded-lg">
                      <Skeleton className="h-10 w-10 rounded-full" />
                      <div className="flex-1">
                        <Skeleton className="h-4 w-1/3 mb-2" />
                        <Skeleton className="h-3 w-1/4" />
                      </div>
                      <Skeleton className="h-8 w-16" />
                    </div>
                  ))}
                </div>
              ) : categories && categories.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Category</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categories.map(category => (
                      <TableRow key={category.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div 
                              className="p-2 rounded-full" 
                              style={{ 
                                backgroundColor: `${category.color}20`,
                                color: category.color
                              }}
                            >
                              {getIconByName(category.icon || "building")}
                            </div>
                            <div className="font-medium">{category.name}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          {category.isDefault ? (
                            <span className="text-sm text-gray-500">System</span>
                          ) : (
                            <span className="text-sm text-gray-500">Custom</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditCategory(category)}
                              disabled={category.isDefault}
                            >
                              <Edit className="h-4 w-4" />
                              <span className="sr-only">Edit</span>
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteCategory(category)}
                              disabled={category.isDefault}
                            >
                              <Trash2 className="h-4 w-4" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-10">
                  <p className="text-gray-500">No categories found.</p>
                  <Button onClick={() => setIsAddDialogOpen(true)} className="mt-4">
                    Add your first category
                  </Button>
                </div>
              )}
            </CardContent>
            <CardFooter className="bg-gray-50 border-t px-6 py-4">
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <Tag className="h-4 w-4" />
                <span>System categories cannot be edited or deleted</span>
              </div>
            </CardFooter>
          </Card>
          
          {/* Delete Confirmation Dialog */}
          <AlertDialog open={!!categoryToDelete} onOpenChange={(open) => !open && setCategoryToDelete(null)}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete the category
                  "{categoryToDelete?.name}" from your account.
                  {categoryToDelete?.isDefault && (
                    <div className="mt-2 text-red-500">
                      System categories cannot be deleted.
                    </div>
                  )}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={confirmDeleteCategory}
                  disabled={categoryToDelete?.isDefault || deleteCategoryMutation.isPending}
                >
                  {deleteCategoryMutation.isPending ? "Deleting..." : "Delete"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </main>
    </div>
  );
}
