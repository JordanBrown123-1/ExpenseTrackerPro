import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { useQuery } from "@tanstack/react-query";
import { Transaction, Category } from "@shared/schema";
import { SpendingChart } from "@/components/ui/spending-chart";
import { CategoryChart, CategoryList } from "@/components/ui/category-chart";
import { 
  Card, 
  CardContent, 
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { 
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  BarChart3, 
  PieChart, 
  TrendingUp, 
  TrendingDown, 
  Download,
  Calendar,
  ArrowRight,
  ArrowUpRight,
  ArrowDownRight
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";

export default function ReportsPage() {
  const [timeFrame, setTimeFrame] = useState("thisMonth");
  const [reportType, setReportType] = useState("overview");
  
  // Get summary data
  const { data: summaryData, isLoading: isLoadingSummary } = useQuery({
    queryKey: ["/api/summary"],
  });
  
  // Get categories for category breakdown
  const { data: categories, isLoading: isLoadingCategories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Get transactions for detailed reports
  const { data: transactions, isLoading: isLoadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  // Calculate monthly spending totals for trend analysis
  const getMonthlyTrend = () => {
    if (!transactions) return [];
    
    // Get last 6 months
    const months = [];
    const today = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
      months.push(d);
    }
    
    // Calculate totals for each month
    return months.map(month => {
      const monthStart = new Date(month.getFullYear(), month.getMonth(), 1);
      const monthEnd = new Date(month.getFullYear(), month.getMonth() + 1, 0);
      
      const monthTransactions = transactions.filter(t => {
        const date = new Date(t.date);
        return date >= monthStart && date <= monthEnd;
      });
      
      const incomeTotal = monthTransactions
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0);
        
      const expenseTotal = monthTransactions
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0);
      
      return {
        month: month.toLocaleString('default', { month: 'short' }),
        income: incomeTotal,
        expenses: expenseTotal,
        balance: incomeTotal - expenseTotal
      };
    });
  };
  
  // Calculate top spending categories
  const getTopCategories = () => {
    if (!transactions || !categories) return [];
    
    // Group expenses by category
    const categoryTotals = new Map();
    let totalExpenses = 0;
    
    // Filter transactions by time frame
    const filteredTransactions = filterTransactionsByTimeFrame(transactions);
    
    // Calculate totals
    filteredTransactions.forEach(transaction => {
      if (transaction.type === 'expense') {
        const { categoryId, amount } = transaction;
        const currentTotal = categoryTotals.get(categoryId) || 0;
        categoryTotals.set(categoryId, currentTotal + amount);
        totalExpenses += amount;
      }
    });
    
    // Convert to array and calculate percentages
    const categoriesArray = Array.from(categoryTotals.entries()).map(([categoryId, amount]) => {
      const category = categories.find(c => c.id === categoryId);
      return {
        id: categoryId,
        name: category?.name || 'Unknown',
        color: category?.color || '#000000',
        icon: category?.icon || 'circle',
        amount: amount,
        percentage: totalExpenses > 0 ? Math.round((amount / totalExpenses) * 100) : 0
      };
    });
    
    // Sort by amount (descending)
    return categoriesArray.sort((a, b) => b.amount - a.amount);
  };
  
  // Filter transactions by selected time frame
  const filterTransactionsByTimeFrame = (transactionsToFilter: Transaction[]) => {
    const now = new Date();
    let startDate: Date;
    let endDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
    
    switch (timeFrame) {
      case 'thisMonth':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'lastMonth':
        startDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        endDate = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59);
        break;
      case 'last3Months':
        startDate = new Date(now.getFullYear(), now.getMonth() - 3, 1);
        break;
      case 'last6Months':
        startDate = new Date(now.getFullYear(), now.getMonth() - 6, 1);
        break;
      case 'thisYear':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    }
    
    return transactionsToFilter.filter(t => {
      const date = new Date(t.date);
      return date >= startDate && date <= endDate;
    });
  };
  
  // Get total income and expenses for the selected time frame
  const getTotals = () => {
    if (!transactions) return { income: 0, expenses: 0, balance: 0 };
    
    const filteredTransactions = filterTransactionsByTimeFrame(transactions);
    
    const income = filteredTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
      
    const expenses = filteredTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
      
    return {
      income,
      expenses,
      balance: income - expenses
    };
  };
  
  // Get time frame label
  const getTimeFrameLabel = () => {
    switch (timeFrame) {
      case 'thisMonth': return 'This Month';
      case 'lastMonth': return 'Last Month';
      case 'last3Months': return 'Last 3 Months';
      case 'last6Months': return 'Last 6 Months';
      case 'thisYear': return 'This Year';
      default: return 'This Month';
    }
  };
  
  const totals = getTotals();
  const monthlyTrend = getMonthlyTrend();
  const topCategories = getTopCategories();

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <div className="p-4 md:p-6 max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center space-x-4">
              <Button variant="outline" onClick={() => window.location.href = '/dashboard'}>
                Back to Dashboard
              </Button>
              <h2 className="text-xl md:text-2xl font-bold text-gray-800">Financial Reports</h2>
            </div>
            
            <div className="flex gap-2">
              <Select value={timeFrame} onValueChange={setTimeFrame}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select time frame" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="thisMonth">This Month</SelectItem>
                  <SelectItem value="lastMonth">Last Month</SelectItem>
                  <SelectItem value="last3Months">Last 3 Months</SelectItem>
                  <SelectItem value="last6Months">Last 6 Months</SelectItem>
                  <SelectItem value="thisYear">This Year</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
          
          <Tabs defaultValue="overview" onValueChange={setReportType}>
            <TabsList className="mb-6">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                <span>Overview</span>
              </TabsTrigger>
              <TabsTrigger value="categories" className="flex items-center gap-2">
                <PieChart className="h-4 w-4" />
                <span>Categories</span>
              </TabsTrigger>
              <TabsTrigger value="trends" className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                <span>Trends</span>
              </TabsTrigger>
            </TabsList>
            
            {/* Overview Report */}
            <TabsContent value="overview">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
                <Card className="col-span-1 lg:col-span-3">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Financial Summary</CardTitle>
                    <CardDescription>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1.5" />
                        <span>{getTimeFrameLabel()}</span>
                      </div>
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {/* Income Card */}
                      <div className="bg-green-50 p-4 rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="text-sm font-medium text-gray-600">Total Income</p>
                            <p className="text-2xl font-bold text-green-600">${totals.income.toFixed(2)}</p>
                          </div>
                          <div className="p-2 bg-white rounded-full">
                            <TrendingUp className="h-5 w-5 text-green-500" />
                          </div>
                        </div>
                      </div>
                      
                      {/* Expenses Card */}
                      <div className="bg-red-50 p-4 rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="text-sm font-medium text-gray-600">Total Expenses</p>
                            <p className="text-2xl font-bold text-red-600">${totals.expenses.toFixed(2)}</p>
                          </div>
                          <div className="p-2 bg-white rounded-full">
                            <TrendingDown className="h-5 w-5 text-red-500" />
                          </div>
                        </div>
                      </div>
                      
                      {/* Balance Card */}
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="text-sm font-medium text-gray-600">Net Balance</p>
                            <p className="text-2xl font-bold text-blue-600">${totals.balance.toFixed(2)}</p>
                          </div>
                          <div className="p-2 bg-white rounded-full">
                            {totals.balance >= 0 ? (
                              <ArrowUpRight className="h-5 w-5 text-green-500" />
                            ) : (
                              <ArrowDownRight className="h-5 w-5 text-red-500" />
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Monthly Spending Chart */}
                <Card className="col-span-1 lg:col-span-2">
                  <CardHeader>
                    <CardTitle>Monthly Spending Overview</CardTitle>
                    <CardDescription>Income vs. Expenses over the last 6 months</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingTransactions ? (
                      <Skeleton className="h-[300px] w-full" />
                    ) : (
                      <SpendingChart data={monthlyTrend} />
                    )}
                  </CardContent>
                </Card>
                
                {/* Top Spending Categories */}
                <Card>
                  <CardHeader>
                    <CardTitle>Top Spending Categories</CardTitle>
                    <CardDescription>{getTimeFrameLabel()}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingTransactions || isLoadingCategories ? (
                      <>
                        <Skeleton className="h-[200px] w-full" />
                        <div className="mt-4 space-y-2">
                          {Array(5).fill(0).map((_, i) => (
                            <div key={i} className="flex items-center justify-between">
                              <Skeleton className="h-4 w-24" />
                              <Skeleton className="h-4 w-12" />
                            </div>
                          ))}
                        </div>
                      </>
                    ) : topCategories.length > 0 ? (
                      <>
                        <CategoryChart data={topCategories} />
                        <CategoryList data={topCategories} />
                      </>
                    ) : (
                      <div className="text-center py-10">
                        <p className="text-gray-500">No expense data available for this period.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
              
              {/* Recent Transactions */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Transactions</CardTitle>
                  <CardDescription>Your latest financial activities</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingTransactions ? (
                    <div className="space-y-4">
                      {Array(5).fill(0).map((_, i) => (
                        <div key={i} className="flex justify-between items-center">
                          <div className="flex items-center gap-3">
                            <Skeleton className="h-10 w-10 rounded-full" />
                            <div>
                              <Skeleton className="h-4 w-32 mb-1" />
                              <Skeleton className="h-3 w-24" />
                            </div>
                          </div>
                          <Skeleton className="h-5 w-20" />
                        </div>
                      ))}
                    </div>
                  ) : transactions && transactions.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Description</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead className="text-right">Amount</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filterTransactionsByTimeFrame(transactions)
                          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                          .slice(0, 5)
                          .map(transaction => (
                            <TableRow key={transaction.id}>
                              <TableCell>
                                {transaction.description || 
                                  (transaction.type === 'income' ? 'Income' : 'Expense')}
                              </TableCell>
                              <TableCell>
                                {categories?.find(c => c.id === transaction.categoryId)?.name || 'Unknown'}
                              </TableCell>
                              <TableCell>
                                {new Date(transaction.date).toLocaleDateString()}
                              </TableCell>
                              <TableCell className={`text-right font-mono font-medium ${
                                transaction.type === 'income' ? 'text-success-500' : 'text-danger-500'
                              }`}>
                                {transaction.type === 'income' ? '+' : '-'}
                                ${transaction.amount.toFixed(2)}
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="text-center py-10">
                      <p className="text-gray-500">No transactions found for this period.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Categories Report */}
            <TabsContent value="categories">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <Card className="col-span-1 md:col-span-2">
                  <CardHeader>
                    <CardTitle>Expense Breakdown by Category</CardTitle>
                    <CardDescription>{getTimeFrameLabel()}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingTransactions || isLoadingCategories ? (
                      <Skeleton className="h-[300px] w-full" />
                    ) : topCategories.length > 0 ? (
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <div className="lg:col-span-1">
                          <CategoryChart data={topCategories} />
                        </div>
                        <div className="lg:col-span-2">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Category</TableHead>
                                <TableHead>Amount</TableHead>
                                <TableHead>Percentage</TableHead>
                                <TableHead className="text-right">Distribution</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {topCategories.map(category => (
                                <TableRow key={category.id}>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      <div 
                                        className="h-3 w-3 rounded-full"
                                        style={{ backgroundColor: category.color }}
                                      ></div>
                                      <span>{category.name}</span>
                                    </div>
                                  </TableCell>
                                  <TableCell className="font-mono">${category.amount.toFixed(2)}</TableCell>
                                  <TableCell>{category.percentage}%</TableCell>
                                  <TableCell className="text-right">
                                    <div className="w-full bg-gray-100 rounded-full h-2.5">
                                      <div 
                                        className="h-2.5 rounded-full" 
                                        style={{ 
                                          width: `${category.percentage}%`,
                                          backgroundColor: category.color
                                        }}
                                      ></div>
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-10">
                        <p className="text-gray-500">No expense data available for this period.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                {/* Category Comparison */}
                <Card>
                  <CardHeader>
                    <CardTitle>Month-over-Month Category Comparison</CardTitle>
                    <CardDescription>Compare your spending patterns</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingTransactions ? (
                      <Skeleton className="h-[300px] w-full" />
                    ) : (
                      <div className="space-y-6">
                        {categories?.filter(c => c.name !== "Income").slice(0, 5).map(category => {
                          // Get monthly spending for this category
                          const monthlyCategoryData = monthlyTrend.map(month => {
                            const monthDate = new Date(new Date().getFullYear(), monthlyTrend.findIndex(m => m.month === month.month), 1);
                            const monthTransactions = transactions?.filter(t => {
                              const date = new Date(t.date);
                              return date.getMonth() === monthDate.getMonth() && 
                                     date.getFullYear() === monthDate.getFullYear() &&
                                     t.categoryId === category.id &&
                                     t.type === 'expense';
                            }) || [];
                            
                            return {
                              month: month.month,
                              amount: monthTransactions.reduce((sum, t) => sum + t.amount, 0)
                            };
                          });
                          
                          // Calculate month-over-month change
                          const currentMonth = monthlyCategoryData[monthlyCategoryData.length - 1].amount;
                          const previousMonth = monthlyCategoryData[monthlyCategoryData.length - 2].amount;
                          const percentChange = previousMonth === 0 
                            ? (currentMonth > 0 ? 100 : 0)
                            : ((currentMonth - previousMonth) / previousMonth) * 100;
                          
                          return (
                            <div key={category.id}>
                              <div className="flex justify-between items-center mb-2">
                                <div className="flex items-center gap-2">
                                  <div 
                                    className="h-3 w-3 rounded-full"
                                    style={{ backgroundColor: category.color }}
                                  ></div>
                                  <span className="font-medium">{category.name}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <span className="text-sm font-mono">${currentMonth.toFixed(2)}</span>
                                  <span className={`text-xs ${
                                    percentChange > 0 ? 'text-red-500' : percentChange < 0 ? 'text-green-500' : 'text-gray-500'
                                  }`}>
                                    {percentChange > 0 ? '+' : ''}
                                    {percentChange.toFixed(1)}%
                                  </span>
                                </div>
                              </div>
                              <div className="h-10 flex items-end gap-1">
                                {monthlyCategoryData.map((data, index) => {
                                  const maxAmount = Math.max(...monthlyCategoryData.map(d => d.amount));
                                  const height = maxAmount === 0 ? 0 : (data.amount / maxAmount) * 100;
                                  
                                  return (
                                    <div key={index} className="flex-1 flex flex-col items-center">
                                      <div 
                                        className="w-full rounded-t-sm" 
                                        style={{ 
                                          height: `${height}%`, 
                                          backgroundColor: category.color,
                                          opacity: index === monthlyCategoryData.length - 1 ? 1 : 0.6
                                        }}
                                      ></div>
                                      <span className="text-xs mt-1">{data.month}</span>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                {/* Top Spending Items */}
                <Card>
                  <CardHeader>
                    <CardTitle>Top Spending Items</CardTitle>
                    <CardDescription>Your largest expenses {getTimeFrameLabel().toLowerCase()}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingTransactions ? (
                      <Skeleton className="h-[300px] w-full" />
                    ) : transactions ? (
                      <div className="space-y-3">
                        {filterTransactionsByTimeFrame(transactions)
                          .filter(t => t.type === 'expense')
                          .sort((a, b) => b.amount - a.amount)
                          .slice(0, 5)
                          .map((transaction, index) => (
                            <div key={transaction.id} className="p-3 border rounded-lg">
                              <div className="flex justify-between items-center">
                                <div className="flex items-center gap-3">
                                  <div className="bg-gray-100 text-gray-700 w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium">
                                    {index + 1}
                                  </div>
                                  <div>
                                    <p className="font-medium">
                                      {transaction.description || 'Expense'}
                                    </p>
                                    <p className="text-xs text-gray-500">
                                      {categories?.find(c => c.id === transaction.categoryId)?.name || 'Unknown'} • {new Date(transaction.date).toLocaleDateString()}
                                    </p>
                                  </div>
                                </div>
                                <span className="font-mono font-semibold text-danger-500">
                                  -${transaction.amount.toFixed(2)}
                                </span>
                              </div>
                            </div>
                          ))}
                        
                        {filterTransactionsByTimeFrame(transactions).filter(t => t.type === 'expense').length === 0 && (
                          <div className="text-center py-6">
                            <p className="text-gray-500">No expenses found for this period.</p>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-10">
                        <p className="text-gray-500">No expense data available.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            {/* Trends Report */}
            <TabsContent value="trends">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <Card className="col-span-1 md:col-span-2">
                  <CardHeader>
                    <CardTitle>Income & Expense Trends</CardTitle>
                    <CardDescription>Your financial patterns over time</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingTransactions ? (
                      <Skeleton className="h-[300px] w-full" />
                    ) : (
                      <SpendingChart data={monthlyTrend} />
                    )}
                  </CardContent>
                </Card>
                
                {/* Saving Rate */}
                <Card>
                  <CardHeader>
                    <CardTitle>Saving Rate Analysis</CardTitle>
                    <CardDescription>How much of your income you save</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingTransactions ? (
                      <Skeleton className="h-[200px] w-full" />
                    ) : (
                      <div className="space-y-6">
                        <div className="text-center">
                          {totals.income > 0 ? (
                            <>
                              <h3 className="text-4xl font-bold mb-2">
                                {Math.round((totals.balance / totals.income) * 100)}%
                              </h3>
                              <p className="text-sm text-gray-600">of your income was saved {getTimeFrameLabel().toLowerCase()}</p>
                            </>
                          ) : (
                            <p className="text-gray-500 py-4">No income recorded for this period.</p>
                          )}
                        </div>
                        
                        {totals.income > 0 && (
                          <div className="space-y-4">
                            <div>
                              <div className="flex justify-between mb-1">
                                <span className="text-sm">Expenses</span>
                                <span className="text-sm">{Math.round((totals.expenses / totals.income) * 100)}%</span>
                              </div>
                              <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-primary"
                                  style={{ width: `${Math.round((totals.expenses / totals.income) * 100)}%` }}
                                />
                              </div>
                            </div>
                            
                            <div>
                              <div className="flex justify-between mb-1">
                                <span className="text-sm">Savings</span>
                                <span className="text-sm">{Math.round((totals.balance / totals.income) * 100)}%</span>
                              </div>
                              <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-green-500"
                                  style={{ width: `${Math.round((totals.balance / totals.income) * 100)}%` }}
                                />
                              </div>
                            </div>
                          </div>
                        )}
                        
                        <div className="pt-4 border-t">
                          <h4 className="font-medium mb-2">Monthly Saving Rate Trend</h4>
                          
                          <div className="space-y-3">
                            {monthlyTrend.map((month, i) => {
                              const savingRate = month.income > 0 
                                ? Math.round(((month.income - month.expenses) / month.income) * 100) 
                                : 0;
                              
                              return (
                                <div key={i}>
                                  <div className="flex justify-between mb-1">
                                    <span className="text-sm">{month.month}</span>
                                    <span className="text-sm">{savingRate}%</span>
                                  </div>
                                  <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                                    <div 
                                      className={`h-full ${savingRate < 0 ? "bg-red-500" : "bg-green-500"}`}
                                      style={{ width: `${Math.max(0, savingRate)}%` }}
                                    />
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                {/* Budget Adherence */}
                <Card>
                  <CardHeader>
                    <CardTitle>Budget Adherence</CardTitle>
                    <CardDescription>How well you're sticking to your budgets</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingTransactions || isLoadingSummary ? (
                      <Skeleton className="h-[200px] w-full" />
                    ) : summaryData && summaryData.budgetProgress ? (
                      <div className="space-y-4">
                        <div className="text-center py-4">
                          <div className="inline-flex items-center justify-center p-4 bg-gray-50 rounded-full mb-2">
                            <div className="relative h-24 w-24">
                              <svg className="w-full h-full" viewBox="0 0 100 100">
                                <circle
                                  className="text-gray-200"
                                  strokeWidth="10"
                                  stroke="currentColor"
                                  fill="transparent"
                                  r="40"
                                  cx="50"
                                  cy="50"
                                />
                                <circle
                                  className={`${
                                    summaryData.summary.budgetStatus > 90 
                                      ? "text-red-500" 
                                      : summaryData.summary.budgetStatus > 70 
                                      ? "text-amber-500" 
                                      : "text-green-500"
                                  }`}
                                  strokeWidth="10"
                                  strokeLinecap="round"
                                  stroke="currentColor"
                                  fill="transparent"
                                  r="40"
                                  cx="50"
                                  cy="50"
                                  strokeDasharray={`${Math.min(100, summaryData.summary.budgetStatus) * 2.51} 251.2`}
                                  strokeDashoffset="0"
                                />
                              </svg>
                              <div className="absolute inset-0 flex items-center justify-center">
                                <span className="text-2xl font-bold">
                                  {summaryData.summary.budgetStatus}%
                                </span>
                              </div>
                            </div>
                          </div>
                          <h3 className="font-medium">Overall Budget Used</h3>
                        </div>
                        
                        <div className="space-y-3">
                          {summaryData.budgetProgress.length > 0 ? (
                            summaryData.budgetProgress.map(budget => (
                              <div key={budget.id}>
                                <div className="flex justify-between mb-1">
                                  <span className="text-sm font-medium">{budget.categoryName}</span>
                                  <span className={`text-sm font-medium ${
                                    budget.percentage >= 90 ? "text-red-500" : 
                                    budget.percentage >= 70 ? "text-amber-500" : 
                                    "text-green-500"
                                  }`}>
                                    {budget.percentage}%
                                  </span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                                    <div 
                                      className={`h-full ${
                                        budget.percentage >= 90 ? "bg-red-500" : 
                                        budget.percentage >= 70 ? "bg-amber-500" : 
                                        "bg-green-500"
                                      }`}
                                      style={{ width: `${Math.min(100, budget.percentage)}%` }}
                                    />
                                  </div>
                                  <span className="text-xs text-gray-500">
                                    ${budget.spent.toFixed(0)} / ${budget.amount.toFixed(0)}
                                  </span>
                                </div>
                              </div>
                            ))
                          ) : (
                            <div className="text-center py-4">
                              <p className="text-gray-500">No budgets set for this period.</p>
                            </div>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-10">
                        <p className="text-gray-500">No budget data available.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
              
              {/* Spending Analysis */}
              <Card>
                <CardHeader>
                  <CardTitle>Spending Pattern Analysis</CardTitle>
                  <CardDescription>Insights into your financial habits</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingTransactions ? (
                    <Skeleton className="h-[200px] w-full" />
                  ) : transactions && transactions.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {/* Weekday Analysis */}
                      <div className="space-y-3">
                        <h3 className="font-medium text-sm mb-2">Spending by Day of Week</h3>
                        
                        {(() => {
                          // Calculate spending by day of week
                          const weekdaySpending = [0, 0, 0, 0, 0, 0, 0]; // Sun to Sat
                          
                          filterTransactionsByTimeFrame(transactions)
                            .filter(t => t.type === 'expense')
                            .forEach(transaction => {
                              const date = new Date(transaction.date);
                              const dayOfWeek = date.getDay(); // 0 = Sunday, 6 = Saturday
                              weekdaySpending[dayOfWeek] += transaction.amount;
                            });
                          
                          const maxSpending = Math.max(...weekdaySpending);
                          const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                          
                          return (
                            <div className="flex items-end h-32 gap-1">
                              {weekdaySpending.map((amount, index) => {
                                const height = maxSpending > 0 ? (amount / maxSpending) * 100 : 0;
                                return (
                                  <div key={index} className="flex-1 flex flex-col items-center">
                                    <div 
                                      className="w-full bg-primary-100 rounded-t" 
                                      style={{ height: `${height}%` }}
                                    ></div>
                                    <span className="text-xs mt-1">{weekdays[index]}</span>
                                  </div>
                                );
                              })}
                            </div>
                          );
                        })()}
                      </div>
                      
                      {/* Income vs Expense */}
                      <div className="space-y-3">
                        <h3 className="font-medium text-sm mb-2">Income vs Expense Distribution</h3>
                        
                        <div className="flex items-center justify-center h-32">
                          <div className="relative w-32 h-32">
                            <svg className="w-full h-full" viewBox="0 0 100 100">
                              <circle
                                className="text-green-400"
                                strokeWidth="20"
                                stroke="currentColor"
                                fill="transparent"
                                r="40"
                                cx="50"
                                cy="50"
                              />
                              <circle
                                className="text-red-400"
                                strokeWidth="20"
                                strokeLinecap="butt"
                                stroke="currentColor"
                                fill="transparent"
                                r="40"
                                cx="50"
                                cy="50"
                                strokeDasharray={`${(totals.expenses / (totals.income + totals.expenses)) * 251.2} 251.2`}
                                strokeDashoffset="0"
                              />
                            </svg>
                          </div>
                        </div>
                        
                        <div className="flex justify-center gap-4 mt-2">
                          <div className="flex items-center gap-1">
                            <div className="w-3 h-3 rounded-full bg-green-400"></div>
                            <span className="text-xs">Income: {(totals.income / (totals.income + totals.expenses) * 100).toFixed(0)}%</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <div className="w-3 h-3 rounded-full bg-red-400"></div>
                            <span className="text-xs">Expenses: {(totals.expenses / (totals.income + totals.expenses) * 100).toFixed(0)}%</span>
                          </div>
                        </div>
                      </div>
                      
                      {/* Average Transaction */}
                      <div className="space-y-3">
                        <h3 className="font-medium text-sm mb-2">Transaction Metrics</h3>
                        
                        {(() => {
                          const expenseTransactions = filterTransactionsByTimeFrame(transactions).filter(t => t.type === 'expense');
                          const incomeTransactions = filterTransactionsByTimeFrame(transactions).filter(t => t.type === 'income');
                          
                          const avgExpense = expenseTransactions.length > 0 
                            ? totals.expenses / expenseTransactions.length 
                            : 0;
                            
                          const avgIncome = incomeTransactions.length > 0 
                            ? totals.income / incomeTransactions.length 
                            : 0;
                            
                          const largestExpense = expenseTransactions.length > 0 
                            ? Math.max(...expenseTransactions.map(t => t.amount))
                            : 0;
                            
                          return (
                            <div className="space-y-4">
                              <div className="flex flex-col items-center justify-center p-4 rounded-lg bg-gray-50">
                                <span className="text-xs text-gray-500">Average Transaction</span>
                                <div className="flex gap-3 mt-1">
                                  <div className="text-center">
                                    <p className="text-xs text-red-500">Expense</p>
                                    <p className="font-mono font-medium">${avgExpense.toFixed(2)}</p>
                                  </div>
                                  <div className="text-center">
                                    <p className="text-xs text-green-500">Income</p>
                                    <p className="font-mono font-medium">${avgIncome.toFixed(2)}</p>
                                  </div>
                                </div>
                              </div>
                              
                              <div className="flex justify-between items-center p-2 rounded-lg bg-gray-50">
                                <span className="text-xs">Largest expense</span>
                                <span className="font-mono font-medium">${largestExpense.toFixed(2)}</span>
                              </div>
                              
                              <div className="flex justify-between items-center p-2 rounded-lg bg-gray-50">
                                <span className="text-xs">Total transactions</span>
                                <span className="font-medium">{expenseTransactions.length + incomeTransactions.length}</span>
                              </div>
                            </div>
                          );
                        })()}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-10">
                      <p className="text-gray-500">Not enough transaction data available for analysis.</p>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="bg-gray-50 border-t">
                  <div className="w-full text-sm text-gray-500 flex justify-center">
                    <span>Reports are based on {getTimeFrameLabel().toLowerCase()} transaction data</span>
                  </div>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
