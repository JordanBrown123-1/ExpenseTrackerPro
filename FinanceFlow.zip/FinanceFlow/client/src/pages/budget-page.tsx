import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Budget, Category, Transaction, budgetFormSchema, insertBudgetSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { exportBudgetsToCSV } from "@/lib/export-utils";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Link } from "wouter";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Plus, Edit, Trash2, Calendar as CalendarIcon, CalendarCheck, Tag, Download } from "lucide-react";

// Type definition for summary data
type SummaryData = {
  summary: {
    income: number;
    expenses: number;
    balance: number;
    incomeChange: number;
    expenseChange: number;
    budgetStatus: number;
  };
  categorySpending: {
    id: number;
    name: string;
    color: string;
    icon: string;
    amount: number;
    percentage: number;
  }[];
  monthlyData: {
    month: string;
    income: number;
    expenses: number;
  }[];
  upcomingBills: {
    id: number;
    name: string;
    amount: number;
    dueDate: string;
    frequency: string;
    categoryId: number;
    paid: boolean;
  }[];
  budgetProgress: {
    id: number;
    categoryId: number;
    categoryName: string;
    amount: number;
    spent: number;
    percentage: number;
  }[];
  recentTransactions: Transaction[];
};

// Extended budget form schema
const extendedBudgetFormSchema = z.object({
  categoryId: z.coerce.number().int().positive("Please select a category"),
  amount: z.coerce.number().positive("Amount must be greater than 0"),
  period: z.string().min(1, "Please select a period"),
  startDate: z.date({
    required_error: "Start date is required",
  }),
  endDate: z.date().optional(),
});

export default function BudgetPage() {
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null);
  const [budgetToDelete, setBudgetToDelete] = useState<Budget | null>(null);
  
  // Get budgets
  const { data: budgets, isLoading: isLoadingBudgets } = useQuery<Budget[]>({
    queryKey: ["/api/budgets"],
  });
  
  // Get categories for dropdown
  const { data: categories, isLoading: isLoadingCategories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Get transactions for budget status calculation
  const { data: summary } = useQuery<SummaryData>({
    queryKey: ["/api/summary"],
  });
  
  // Form for adding/editing budget
  const form = useForm<z.infer<typeof extendedBudgetFormSchema>>({
    resolver: zodResolver(extendedBudgetFormSchema),
    defaultValues: {
      categoryId: 0,
      amount: 0,
      period: "monthly",
      startDate: new Date(),
    },
  });
  
  // Create budget mutation
  const createBudgetMutation = useMutation({
    mutationFn: async (values: z.infer<typeof extendedBudgetFormSchema>) => {
      // Send date objects directly - the API will parse them correctly
      const res = await apiRequest("POST", "/api/budgets", values);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      setIsAddDialogOpen(false);
      form.reset();
      toast({
        title: "Budget created",
        description: "The budget has been created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create budget",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update budget mutation
  const updateBudgetMutation = useMutation({
    mutationFn: async ({ id, values }: { id: number; values: z.infer<typeof extendedBudgetFormSchema> }) => {
      // Send date objects directly - the API will parse them correctly
      const res = await apiRequest("PUT", `/api/budgets/${id}`, values);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      setIsAddDialogOpen(false);
      setEditingBudget(null);
      form.reset();
      toast({
        title: "Budget updated",
        description: "The budget has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update budget",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete budget mutation
  const deleteBudgetMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/budgets/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      setBudgetToDelete(null);
      toast({
        title: "Budget deleted",
        description: "The budget has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete budget",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (values: z.infer<typeof extendedBudgetFormSchema>) => {
    if (editingBudget) {
      updateBudgetMutation.mutate({ id: editingBudget.id, values });
    } else {
      createBudgetMutation.mutate(values);
    }
  };
  
  // Handle edit budget
  const handleEditBudget = (budget: Budget) => {
    setEditingBudget(budget);
    form.reset({
      categoryId: budget.categoryId,
      amount: budget.amount,
      period: budget.period,
      startDate: new Date(budget.startDate),
      endDate: budget.endDate ? new Date(budget.endDate) : undefined,
    });
    setIsAddDialogOpen(true);
  };
  
  // Handle delete budget
  const handleDeleteBudget = (budget: Budget) => {
    setBudgetToDelete(budget);
  };
  
  // Confirm delete budget
  const confirmDeleteBudget = () => {
    if (budgetToDelete) {
      deleteBudgetMutation.mutate(budgetToDelete.id);
    }
  };
  
  // Close dialog and reset form
  const closeDialog = () => {
    setIsAddDialogOpen(false);
    setEditingBudget(null);
    form.reset({
      categoryId: 0,
      amount: 0,
      period: "monthly",
      startDate: new Date(),
    });
  };
  
  // Get category name by ID
  const getCategoryName = (categoryId: number) => {
    const category = categories?.find(c => c.id === categoryId);
    return category?.name || "Unknown";
  };
  
  // Get budget progress from summary data
  const getBudgetProgress = (budgetId: number) => {
    if (!summary) return { spent: 0, percentage: 0 };
    
    // TypeScript safeguard - initialize budgetProgress as an empty array if it doesn't exist
    const budgetProgressData = summary.budgetProgress || [];
    
    const progress = budgetProgressData.find(b => b.id === budgetId);
    return progress || { spent: 0, percentage: 0 };
  };
  
  // Handle export budgets to CSV
  const handleExportBudgets = () => {
    if (budgets && categories) {
      exportBudgetsToCSV(budgets, categories);
      
      toast({
        title: "Export successful",
        description: "Your budgets have been exported as a CSV file.",
      });
    } else {
      toast({
        title: "Export failed",
        description: "There are no budgets to export.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <div className="p-4 md:p-6 max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Link to="/dashboard">
                <Button variant="outline" size="sm">
                  ← Back to Dashboard
                </Button>
              </Link>
              <h2 className="text-xl md:text-2xl font-bold text-gray-800">Budgets</h2>
            </div>
            
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={handleExportBudgets}
                disabled={!budgets || budgets.length === 0}
              >
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
              
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <Button onClick={() => setIsAddDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Budget
                </Button>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>{editingBudget ? "Edit Budget" : "Create New Budget"}</DialogTitle>
                    <DialogDescription>
                      {editingBudget 
                        ? "Update your budget details below." 
                        : "Set up a new budget to help manage your spending."}
                    </DialogDescription>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="categoryId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Category</FormLabel>
                            <Select 
                              onValueChange={(value) => field.onChange(parseInt(value))}
                              value={field.value ? field.value.toString() : ""}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {categories?.filter(cat => cat.name !== "Income").map(category => (
                                  <SelectItem key={category.id} value={category.id.toString()}>
                                    {category.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="amount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Budget Amount</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                  <span className="text-gray-500">$</span>
                                </div>
                                <Input 
                                  placeholder="0.00" 
                                  type="number" 
                                  className="pl-8" 
                                  {...field}
                                  onChange={(e) => field.onChange(parseFloat(e.target.value))}
                                />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="period"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Budget Period</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a period" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="monthly">Monthly</SelectItem>
                                <SelectItem value="quarterly">Quarterly</SelectItem>
                                <SelectItem value="yearly">Yearly</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="startDate"
                          render={({ field }) => (
                            <FormItem className="flex flex-col">
                              <FormLabel>Start Date</FormLabel>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <FormControl>
                                    <Button
                                      variant={"outline"}
                                      className="pl-3 text-left font-normal"
                                    >
                                      {field.value ? (
                                        format(field.value, "PPP")
                                      ) : (
                                        <span>Pick a date</span>
                                      )}
                                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                    </Button>
                                  </FormControl>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                  <Calendar
                                    mode="single"
                                    selected={field.value}
                                    onSelect={field.onChange}
                                    initialFocus
                                  />
                                </PopoverContent>
                              </Popover>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="endDate"
                          render={({ field }) => (
                            <FormItem className="flex flex-col">
                              <FormLabel>End Date (Optional)</FormLabel>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <FormControl>
                                    <Button
                                      variant={"outline"}
                                      className="pl-3 text-left font-normal"
                                    >
                                      {field.value ? (
                                        format(field.value, "PPP")
                                      ) : (
                                        <span>Pick a date</span>
                                      )}
                                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                    </Button>
                                  </FormControl>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                  <div className="p-2 border-b">
                                    <Button 
                                      variant="ghost" 
                                      size="sm" 
                                      onClick={() => field.onChange(undefined)}
                                      className="text-xs"
                                    >
                                      Clear date
                                    </Button>
                                  </div>
                                  <Calendar
                                    mode="single"
                                    selected={field.value}
                                    onSelect={field.onChange}
                                    initialFocus
                                    disabled={(date) => 
                                      date < (form.getValues("startDate") || new Date())
                                    }
                                  />
                                </PopoverContent>
                              </Popover>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <DialogFooter>
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={closeDialog}
                        >
                          Cancel
                        </Button>
                        <Button type="submit" disabled={createBudgetMutation.isPending || updateBudgetMutation.isPending}>
                          {createBudgetMutation.isPending || updateBudgetMutation.isPending
                            ? "Saving..."
                            : editingBudget
                            ? "Update Budget"
                            : "Create Budget"}
                        </Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Budget List */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Your Budgets</CardTitle>
                  <CardDescription>
                    Track your spending against budget targets
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingBudgets || isLoadingCategories ? (
                    <div className="space-y-4">
                      {Array(4).fill(0).map((_, i) => (
                        <div key={i} className="p-4 border rounded-lg">
                          <div className="flex justify-between mb-2">
                            <Skeleton className="h-5 w-1/3" />
                            <Skeleton className="h-5 w-16" />
                          </div>
                          <Skeleton className="h-4 w-full mb-2" />
                          <div className="flex justify-between">
                            <Skeleton className="h-4 w-1/4" />
                            <Skeleton className="h-4 w-1/4" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : budgets && budgets.length > 0 ? (
                    <div className="space-y-6">
                      {budgets.map(budget => {
                        const progress = getBudgetProgress(budget.id);
                        
                        // Determine progress color
                        const getStatusColor = (percentage: number) => {
                          if (percentage >= 90) return "bg-danger-500";
                          if (percentage >= 70) return "bg-amber-500";
                          return "bg-success-500";
                        };
                        
                        return (
                          <div key={budget.id} className="p-5 border rounded-lg">
                            <div className="flex justify-between items-start mb-3">
                              <div>
                                <h3 className="font-semibold text-lg">{getCategoryName(budget.categoryId)}</h3>
                                <p className="text-sm text-gray-500 flex items-center gap-1">
                                  <CalendarCheck className="h-3.5 w-3.5" />
                                  {budget.period.charAt(0).toUpperCase() + budget.period.slice(1)}
                                </p>
                              </div>
                              <div className="text-right">
                                <div className="font-mono font-semibold text-lg">${budget.amount.toFixed(2)}</div>
                                <div className="text-sm text-gray-500">
                                  {format(new Date(budget.startDate), "MMM d")} 
                                  {budget.endDate ? ` - ${format(new Date(budget.endDate), "MMM d")}` : ""}
                                </div>
                              </div>
                            </div>
                            
                            <div className="mb-2">
                              <div className="flex justify-between text-sm mb-1">
                                <span>Spent: ${progress.spent.toFixed(2)}</span>
                                <span className={progress.percentage >= 100 ? "text-danger-500" : ""}>
                                  {progress.percentage}%
                                </span>
                              </div>
                              <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full ${getStatusColor(progress.percentage)}`}
                                  style={{ width: `${Math.min(100, progress.percentage)}%` }}
                                />
                              </div>
                            </div>
                            
                            <div className="flex justify-end gap-2 mt-4">
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => handleEditBudget(budget)}
                              >
                                <Edit className="h-4 w-4 mr-1" />
                                Edit
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handleDeleteBudget(budget)}
                              >
                                <Trash2 className="h-4 w-4 mr-1" />
                                Delete
                              </Button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-10">
                      <p className="text-gray-500 mb-4">You haven't created any budgets yet.</p>
                      <Button 
                        onClick={() => setIsAddDialogOpen(true)}
                        className="mb-6"
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Create Your First Budget
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
            
            {/* Budget Tips */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Budgeting Tips</CardTitle>
                  <CardDescription>
                    Best practices for financial success
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingBudgets ? (
                    <div className="space-y-4">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-5/6" />
                      <Skeleton className="h-4 w-4/6" />
                    </div>
                  ) : (
                    <>
                      <div className="mb-6">
                        <h3 className="font-semibold mb-2">Why budgeting matters</h3>
                        <p className="text-gray-600 text-sm mb-4">
                          Budgeting helps you take control of your finances, reduce stress, and achieve your financial goals faster.
                        </p>
                        
                        <h3 className="font-semibold mb-2">Budget Tips</h3>
                        <ul className="space-y-3 text-sm text-gray-600">
                          <li className="flex items-start gap-2">
                            <div className="bg-primary-100 text-primary-600 p-1 rounded mt-0.5">
                              <Tag className="h-3 w-3" />
                            </div>
                            <span>Create separate budgets for different expense categories</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <div className="bg-primary-100 text-primary-600 p-1 rounded mt-0.5">
                              <Tag className="h-3 w-3" />
                            </div>
                            <span>Review and adjust your budgets regularly</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <div className="bg-primary-100 text-primary-600 p-1 rounded mt-0.5">
                              <Tag className="h-3 w-3" />
                            </div>
                            <span>Set realistic budget goals based on your spending habits</span>
                          </li>
                        </ul>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
          
          {/* Delete Confirmation Dialog */}
          <AlertDialog open={!!budgetToDelete} onOpenChange={(open) => !open && setBudgetToDelete(null)}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Budget</AlertDialogTitle>
                <AlertDialogDescription>
                  Are you sure you want to delete this budget? This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={confirmDeleteBudget}
                  disabled={deleteBudgetMutation.isPending}
                >
                  {deleteBudgetMutation.isPending ? "Deleting..." : "Delete"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </main>
    </div>
  );
}