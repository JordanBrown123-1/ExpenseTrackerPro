import { useEffect, useRef } from "react";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  ChartData,
  ChartOptions,
  DoughnutController
} from "chart.js";

// Register components directly in this file
ChartJS.register(
  ArcElement,
  DoughnutController,
  Tooltip,
  Legend
);

type CategoryChartProps = {
  data: {
    id: number;
    name: string;
    color: string;
    percentage: number;
  }[];
};

export function CategoryChart({ data }: CategoryChartProps) {
  const chartRef = useRef<HTMLCanvasElement | null>(null);
  const chartInstance = useRef<ChartJS | null>(null);

  useEffect(() => {
    if (!chartRef.current || !data.length) return;

    const ctx = chartRef.current.getContext("2d");
    if (!ctx) return;

    // Cleanup previous chart
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    const labels = data.map(item => item.name);
    const percentages = data.map(item => item.percentage);
    const colors = data.map(item => item.color);

    const chartData: ChartData<"doughnut"> = {
      labels,
      datasets: [{
        data: percentages,
        backgroundColor: colors,
        borderWidth: 0,
        borderRadius: 3
      }]
    };

    const options: ChartOptions<"doughnut"> = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          backgroundColor: 'rgba(255, 255, 255, 0.95)',
          titleColor: '#1F2937',
          bodyColor: '#1F2937',
          borderColor: 'rgba(0, 0, 0, 0.1)',
          borderWidth: 1,
          padding: 10,
          boxPadding: 5,
          callbacks: {
            label: function(context) {
              return `${context.label}: ${context.raw}%`;
            }
          }
        }
      },
      cutout: '70%'
    };

    chartInstance.current = new ChartJS(ctx, {
      type: 'doughnut',
      data: chartData,
      options
    });

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data]);

  return (
    <div className="h-[200px] flex justify-center">
      <canvas ref={chartRef} />
    </div>
  );
}

export function CategoryList({ data }: CategoryChartProps) {
  return (
    <div className="mt-4 space-y-2">
      {data.map((category) => (
        <div key={category.id} className="flex items-center justify-between text-sm">
          <div className="flex items-center">
            <span 
              className="category-dot" 
              style={{ backgroundColor: category.color }}
            ></span>
            <span>{category.name}</span>
          </div>
          <span className="font-semibold">{category.percentage}%</span>
        </div>
      ))}
    </div>
  );
}
