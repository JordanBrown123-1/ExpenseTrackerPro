import { useEffect, useRef } from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ChartData,
  ChartOptions,
  BarController
} from "chart.js";

// Register components directly in this file
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  BarController,
  Title,
  Tooltip,
  Legend
);

type SpendingChartProps = {
  data: {
    month: string;
    income: number;
    expenses: number;
  }[];
};

export function SpendingChart({ data }: SpendingChartProps) {
  const chartRef = useRef<HTMLCanvasElement | null>(null);
  const chartInstance = useRef<ChartJS | null>(null);

  useEffect(() => {
    if (!chartRef.current || !data.length) return;

    const ctx = chartRef.current.getContext("2d");
    if (!ctx) return;

    // Cleanup previous chart
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    const labels = data.map(item => item.month);
    const incomeData = data.map(item => item.income);
    const expensesData = data.map(item => item.expenses);

    const chartData: ChartData<"bar"> = {
      labels,
      datasets: [
        {
          label: 'Income',
          data: incomeData,
          backgroundColor: '#10B981',
          borderRadius: 6,
          barPercentage: 0.6,
        },
        {
          label: 'Expenses',
          data: expensesData,
          backgroundColor: '#EF4444',
          borderRadius: 6,
          barPercentage: 0.6,
        }
      ]
    };

    const options: ChartOptions<"bar"> = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'top',
          align: 'end',
          labels: {
            boxWidth: 15,
            usePointStyle: true,
            pointStyle: 'circle'
          }
        },
        tooltip: {
          backgroundColor: 'rgba(255, 255, 255, 0.95)',
          titleColor: '#1F2937',
          bodyColor: '#1F2937',
          borderColor: 'rgba(0, 0, 0, 0.1)',
          borderWidth: 1,
          padding: 10,
          boxPadding: 5,
          usePointStyle: true,
          callbacks: {
            label: function(context) {
              return `${context.dataset.label}: $${context.raw}`;
            }
          }
        }
      },
      scales: {
        x: {
          grid: {
            display: false
          }
        },
        y: {
          beginAtZero: true,
          grid: {
            // Using color and lineWidth instead of borderDash for compatibility
            color: 'rgba(0, 0, 0, 0.1)',
            lineWidth: 1
          },
          ticks: {
            callback: function(value) {
              return '$' + Number(value).toLocaleString();
            }
          }
        }
      }
    };

    chartInstance.current = new ChartJS(ctx, {
      type: 'bar',
      data: chartData,
      options
    });

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data]);

  return (
    <div className="h-[300px]">
      <canvas ref={chartRef} />
    </div>
  );
}
