import React, { useEffect, useRef } from 'react';

type BudgetCardProps = {
  categoryName: string;
  spent: number;
  amount: number;
  percentage: number;
};

export function BudgetCard({ categoryName, spent, amount, percentage }: BudgetCardProps) {
  const progressBarRef = useRef<HTMLDivElement>(null);
  
  // Determine progress bar color
  const getColor = () => {
    if (percentage >= 90) return "#ef4444"; // red
    if (percentage >= 70) return "#f59e0b"; // amber
    return "#10b981"; // green
  };

  // Update the progress bar width using direct DOM manipulation
  useEffect(() => {
    if (progressBarRef.current) {
      const safePercentage = Math.max(0, Math.min(100, percentage));
      progressBarRef.current.style.width = `${safePercentage}%`;
    }
  }, [percentage]);
  
  return (
    <div className="mb-4">
      <div className="flex items-center justify-between mb-1.5">
        <div>
          <span className="font-medium text-gray-800">{categoryName}</span>
          <span className="text-xs text-gray-500 ml-2">
            ${spent.toFixed(2)} / ${amount.toFixed(2)}
          </span>
        </div>
        <span style={{ color: getColor() }} className="text-sm font-medium">
          {percentage}%
        </span>
      </div>
      
      {/* Extremely simple progress bar */}
      <div 
        style={{ 
          backgroundColor: '#f3f4f6', 
          borderRadius: '9999px',
          height: '8px',
          width: '100%',
          position: 'relative'
        }}
      >
        <div
          ref={progressBarRef}
          style={{
            backgroundColor: getColor(),
            height: '100%',
            width: '0%', // Initial width, will be updated by useEffect
            borderRadius: '9999px',
            transition: 'width 0.3s ease'
          }}
        />
      </div>
    </div>
  );
}
