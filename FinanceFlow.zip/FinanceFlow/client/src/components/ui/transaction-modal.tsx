import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Category, InsertTransaction, transactionFormSchema } from "@shared/schema";
import { format } from "date-fns";
import { useTransactionContext } from "@/contexts/transaction-context";

type TransactionModalProps = {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  transaction?: any;
};

export function TransactionModal({ isOpen, onClose, categories, transaction }: TransactionModalProps) {
  const [transactionType, setTransactionType] = useState<'expense' | 'income'>(
    transaction?.type as 'expense' | 'income' || 'expense'
  );
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEditMode = !!transaction?.id;

  // Form definition with validation
  const form = useForm<z.infer<typeof transactionFormSchema>>({
    resolver: zodResolver(transactionFormSchema),
    defaultValues: {
      type: transaction?.type || 'expense',
      amount: transaction?.amount || 0,
      date: transaction?.date ? new Date(transaction.date) : new Date(),
      description: transaction?.description || '',
      notes: transaction?.notes || '',
      categoryId: transaction?.categoryId
    }
  });

  // Get transaction functions from context
  const { createTransaction, updateTransaction } = useTransactionContext();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Handle form submission
  const onSubmit = async (data: z.infer<typeof transactionFormSchema>) => {
    setIsSubmitting(true);
    
    try {
      // Ensure date is properly formatted
      let formattedDate = data.date;
      if (!(formattedDate instanceof Date) && typeof formattedDate === 'string') {
        formattedDate = new Date(formattedDate);
      }

      const submissionData = {
        ...data,
        date: formattedDate,
        type: transactionType
      };

      console.log("Submitting transaction data:", submissionData);

      if (isEditMode && transaction?.id) {
        await updateTransaction(transaction.id, submissionData);
        toast({
          title: "Transaction updated",
          description: "Your transaction has been updated successfully."
        });
      } else {
        await createTransaction(submissionData);
        toast({
          title: "Transaction added",
          description: "Your transaction has been added successfully."
        });
      }
      
      // Close modal and reset form
      onClose();
      form.reset();
    } catch (error) {
      console.error("Transaction submission error:", error);
      toast({
        title: isEditMode ? "Error updating transaction" : "Error adding transaction",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditMode ? 'Edit Transaction' : 'Add New Transaction'}</DialogTitle>
          <DialogDescription>
            Enter the details of your transaction below.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          {/* Transaction Type */}
          <div className="space-y-1">
            <Label>Transaction Type</Label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setTransactionType('expense')}
                className={`flex items-center justify-center border rounded-lg p-3 cursor-pointer hover:bg-gray-50 transition-colors ${
                  transactionType === 'expense' ? 'bg-primary-50 border-primary-500 text-primary-700 ring-2 ring-primary-500' : ''
                }`}
              >
                <span>Expense</span>
              </button>
              <button
                type="button"
                onClick={() => setTransactionType('income')}
                className={`flex items-center justify-center border rounded-lg p-3 cursor-pointer hover:bg-gray-50 transition-colors ${
                  transactionType === 'income' ? 'bg-green-50 border-green-500 text-green-700 ring-2 ring-green-500' : ''
                }`}
              >
                <span>Income</span>
              </button>
            </div>
          </div>

          {/* Amount */}
          <div className="space-y-1">
            <Label htmlFor="amount">Amount</Label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <span className="text-gray-500">$</span>
              </div>
              <Input
                id="amount"
                placeholder="0.00"
                className="pl-8"
                {...form.register("amount", { valueAsNumber: true })}
              />
            </div>
            {form.formState.errors.amount && (
              <p className="text-sm text-red-500">{form.formState.errors.amount.message}</p>
            )}
          </div>

          {/* Category */}
          <div className="space-y-1">
            <Label htmlFor="category">Category</Label>
            <Select
              onValueChange={(value) => form.setValue("categoryId", parseInt(value))}
              defaultValue={transaction?.categoryId ? transaction.categoryId.toString() : ""}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {categories
                  .filter(cat => 
                    (transactionType === 'income' && cat.name === 'Income') || 
                    (transactionType === 'expense' && cat.name !== 'Income')
                  )
                  .map(category => (
                    <SelectItem key={category.id} value={category.id.toString()}>
                      {category.name}
                    </SelectItem>
                  ))
                }
              </SelectContent>
            </Select>
            {form.formState.errors.categoryId && (
              <p className="text-sm text-red-500">{form.formState.errors.categoryId.message}</p>
            )}
          </div>

          {/* Date */}
          <div className="space-y-1">
            <Label htmlFor="date">Date</Label>
            <Input
              id="date"
              type="date"
              defaultValue={transaction?.date 
                ? format(new Date(transaction.date), 'yyyy-MM-dd') 
                : format(new Date(), 'yyyy-MM-dd')}
              {...form.register("date", { valueAsDate: true })}
            />
            {form.formState.errors.date && (
              <p className="text-sm text-red-500">{form.formState.errors.date.message}</p>
            )}
          </div>

          {/* Description */}
          <div className="space-y-1">
            <Label htmlFor="description">Description</Label>
            <Input
              id="description"
              placeholder="e.g., Grocery shopping"
              {...form.register("description")}
            />
          </div>

          {/* Notes */}
          <div className="space-y-1">
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea
              id="notes"
              placeholder="Add any additional details"
              {...form.register("notes")}
            />
          </div>

          <DialogFooter>
            <Button 
              type="submit" 
              className="w-full" 
              disabled={isSubmitting}
            >
              {isEditMode 
                ? (isSubmitting ? "Updating..." : "Update Transaction")
                : (isSubmitting ? "Adding..." : "Add Transaction")
              }
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
