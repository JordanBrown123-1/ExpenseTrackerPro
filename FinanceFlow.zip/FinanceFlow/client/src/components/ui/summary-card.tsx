import { ArrowUpCircle, ArrowDownCircle, Wallet, PieChart } from "lucide-react";

type SummaryCardProps = {
  title: string;
  amount: number;
  type: "income" | "expense" | "balance" | "budget";
  change?: number;
  budgetStatus?: number;
};

export function SummaryCard({ title, amount, type, change, budgetStatus }: SummaryCardProps) {
  // Generate icon based on type
  const getIcon = () => {
    switch (type) {
      case "income":
        return <ArrowUpCircle className="text-lg" />;
      case "expense":
        return <ArrowDownCircle className="text-lg" />;
      case "balance":
        return <Wallet className="text-lg" />;
      case "budget":
        return <PieChart className="text-lg" />;
    }
  };

  // Generate background color based on type
  const getBgColor = () => {
    switch (type) {
      case "income":
        return "bg-green-50 text-success-500";
      case "expense":
        return "bg-red-50 text-danger-500";
      case "balance":
        return "bg-blue-50 text-primary-500";
      case "budget":
        return "bg-amber-50 text-warning-500";
    }
  };

  // Generate change text based on type and change value
  const getChangeText = () => {
    if (type === "balance") {
      return "Current month savings";
    }
    
    if (change === undefined) return null;
    
    const isPositive = change > 0;
    const changeText = `${isPositive ? "+" : ""}${change.toFixed(1)}% from last month`;
    
    if (type === "income") {
      return (
        <div className={`mt-3 text-xs flex items-center ${isPositive ? "text-success-500" : "text-danger-500"}`}>
          <span>{changeText}</span>
        </div>
      );
    } else if (type === "expense") {
      return (
        <div className={`mt-3 text-xs flex items-center ${!isPositive ? "text-success-500" : "text-danger-500"}`}>
          <span>{changeText}</span>
        </div>
      );
    }
  };

  // Format amount as currency
  const formattedAmount = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount);

  return (
    <div className="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <span className={`p-2 ${getBgColor()} rounded-lg`}>
          {getIcon()}
        </span>
      </div>
      
      {type === "budget" ? (
        <>
          <p className="mt-2 text-2xl font-semibold font-mono">{budgetStatus}%</p>
          <div className="mt-3 relative w-full h-2 bg-gray-100 rounded-full">
            <div 
              className="absolute top-0 left-0 h-2 bg-warning-500 rounded-full" 
              style={{ width: `${budgetStatus}%` }}
            ></div>
          </div>
        </>
      ) : (
        <>
          <p className="mt-2 text-2xl font-semibold font-mono">{formattedAmount}</p>
          {getChangeText()}
        </>
      )}
    </div>
  );
}
