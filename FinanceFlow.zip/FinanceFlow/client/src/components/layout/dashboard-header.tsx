import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Download, Plus, ArrowLeft, FileText, FileSpreadsheet, LogOut } from "lucide-react";
import { TransactionModal } from "@/components/ui/transaction-modal";
import { useQuery } from "@tanstack/react-query";
import { Category, Transaction } from "@shared/schema";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Link } from "wouter";
import { exportTransactionsToCSV, exportSummaryToCSV } from "@/lib/export-utils";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import jsPDF from "jspdf";
import "jspdf-autotable";

type DashboardHeaderProps = {
  title: string;
  summaryData?: any;  // Add summary data prop
};

export function DashboardHeader({ title, showBackButton = false, summaryData }: DashboardHeaderProps & { showBackButton?: boolean }) {
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  const { toast } = useToast();
  const { logoutMutation, user } = useAuth();
  
  // Fetch categories for the transaction modal
  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Fetch transactions for export
  const { data: transactions } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const handleExportCSV = () => {
    try {
      if (!transactions || !categories) {
        toast({
          title: "Export failed",
          description: "Could not retrieve transaction data for export",
          variant: "destructive",
        });
        return;
      }
      
      if (summaryData) {
        // If we have summary data, export the summary report
        exportSummaryToCSV(summaryData, categories);
      } else {
        // Otherwise just export transactions
        exportTransactionsToCSV(transactions, categories);
      }
      
      toast({
        title: "Export successful",
        description: "Your financial data has been exported as CSV",
      });
    } catch (error) {
      console.error("Failed to export CSV:", error);
      toast({
        title: "Export failed",
        description: "An error occurred while exporting your data",
        variant: "destructive",
      });
    }
  };
  
  const handleExportPDF = () => {
    try {
      if (!transactions || !categories) {
        toast({
          title: "Export failed",
          description: "Could not retrieve transaction data for export",
          variant: "destructive",
        });
        return;
      }
      
      // Create a new PDF document
      const doc = new jsPDF();
      doc.setFontSize(22);
      doc.text("Financial Report", 20, 20);
      doc.setFontSize(12);
      doc.text(`Generated on ${new Date().toLocaleDateString()}`, 20, 30);
      
      // Add summary section if available
      if (summaryData && summaryData.summary) {
        doc.setFontSize(16);
        doc.text("Financial Summary", 20, 40);
        doc.setFontSize(12);
        
        const summaryRows = [
          ["Income", `$${summaryData.summary.income.toFixed(2)}`],
          ["Expenses", `$${summaryData.summary.expenses.toFixed(2)}`],
          ["Balance", `$${summaryData.summary.balance.toFixed(2)}`],
        ];
        
        (doc as any).autoTable({
          startY: 45,
          head: [["Item", "Amount"]],
          body: summaryRows,
          theme: 'striped',
          styles: { fontSize: 10 },
        });
      }
      
      // Add transactions table
      const formattedTransactions = transactions.map(transaction => [
        new Date(transaction.date).toLocaleDateString(),
        transaction.type.charAt(0).toUpperCase() + transaction.type.slice(1),
        categories.find(c => c.id === transaction.categoryId)?.name || "Uncategorized",
        `$${transaction.amount.toFixed(2)}`,
        transaction.description || "",
      ]);
      
      const startY = summaryData && summaryData.summary ? 80 : 40;
      
      // Add transactions table
      (doc as any).autoTable({
        startY: startY,
        head: [["Date", "Type", "Category", "Amount", "Description"]],
        body: formattedTransactions,
        theme: 'striped',
        styles: { fontSize: 10 },
      });
      
      // Save the PDF
      doc.save(`financial_report_${new Date().toISOString().slice(0, 10)}.pdf`);
      
      toast({
        title: "Export successful",
        description: "Your financial data has been exported as PDF",
      });
    } catch (error) {
      console.error("Failed to export PDF:", error);
      toast({
        title: "Export failed",
        description: "An error occurred while exporting your data",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="md:flex md:items-center md:justify-between mb-6">
      <div className="flex items-center gap-3">
        {showBackButton && (
          <Link to="/dashboard">
            <Button variant="outline" size="sm" className="gap-1.5">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>
        )}
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-gray-800">{title}</h2>
          {user && (
            <p className="text-sm text-gray-500">
              Welcome, <span className="font-semibold">{user.username}</span>
            </p>
          )}
        </div>
      </div>
      
      {/* Action Buttons */}
      <div className="mt-3 md:mt-0 flex space-x-2">
        <Button 
          variant="default" 
          onClick={() => setIsTransactionModalOpen(true)}
          className="gap-1.5"
        >
          <Plus className="h-4 w-4" />
          <span>New Transaction</span>
        </Button>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="gap-1.5">
              <Download className="h-4 w-4" />
              <span>Export</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={handleExportCSV} className="flex items-center gap-2">
              <FileSpreadsheet className="h-4 w-4" />
              Export as CSV
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleExportPDF} className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Export as PDF
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        
        <Button 
          variant="outline" 
          onClick={handleLogout}
          className="gap-1.5 text-red-500 hover:text-red-600 hover:bg-red-50 border-red-200"
        >
          <LogOut className="h-4 w-4" />
          <span className="hidden sm:inline">Sign Out</span>
        </Button>
      </div>
      
      {/* Transaction Modal */}
      {isTransactionModalOpen && (
        <TransactionModal 
          isOpen={isTransactionModalOpen}
          onClose={() => setIsTransactionModalOpen(false)}
          categories={categories || []}
        />
      )}
    </div>
  );
}
