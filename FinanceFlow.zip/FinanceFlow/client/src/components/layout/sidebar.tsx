import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  LayoutDashboard, 
  DollarSign, 
  BarChart2, 
  PiggyBank, 
  Tag, 
  Settings, 
  LogOut, 
  Menu, 
  X 
} from "lucide-react";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  // Navigation links
  const navLinks = [
    { path: "/dashboard", label: "Dashboard", icon: <LayoutDashboard className="h-5 w-5" /> },
    { path: "/transactions", label: "Transactions", icon: <DollarSign className="h-5 w-5" /> },
    { path: "/reports", label: "Reports", icon: <BarChart2 className="h-5 w-5" /> },
    { path: "/budgets", label: "Budgets", icon: <PiggyBank className="h-5 w-5" /> },
    { path: "/categories", label: "Categories", icon: <Tag className="h-5 w-5" /> },
    { path: "/settings", label: "Settings", icon: <Settings className="h-5 w-5" /> },
  ];

  // Mobile header
  const MobileHeader = () => (
    <header className="bg-white shadow-sm md:hidden p-4 flex items-center justify-between">
      <div className="flex items-center">
        <div className="h-8 w-8 bg-primary-500 text-white rounded-lg flex items-center justify-center mr-2">
          <DollarSign className="h-5 w-5" />
        </div>
        <h1 className="text-lg font-semibold text-gray-800">ExpenseTrackerPro</h1>
      </div>
      <Button 
        variant="ghost" 
        size="icon" 
        onClick={toggleMobileMenu} 
        aria-label="Toggle menu"
      >
        <Menu className="h-5 w-5" />
      </Button>
    </header>
  );

  // Sidebar content
  const SidebarContent = () => (
    <>
      <div className="p-5 border-b">
        <div className="flex items-center space-x-3">
          <div className="h-8 w-8 bg-primary-500 text-white rounded-lg flex items-center justify-center">
            <DollarSign className="h-5 w-5" />
          </div>
          <h1 className="text-lg font-bold text-gray-800">ExpenseTrackerPro</h1>
        </div>
      </div>
      
      <div className="flex flex-col justify-between h-full">
        <nav className="py-4 px-3 space-y-1">
          {navLinks.map(link => (
            <div key={link.path}>
              <Link 
                href={link.path}
                onClick={closeMobileMenu}
              >
                <div 
                  className={`flex items-center space-x-3 px-3 py-2.5 rounded-lg font-medium cursor-pointer ${
                    location === link.path
                      ? "bg-primary-50 text-primary-600"
                      : "text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  {link.icon}
                  <span>{link.label}</span>
                </div>
              </Link>
            </div>
          ))}
        </nav>
        
        <div className="mt-auto border-t border-gray-200">
          <div className="p-4">
            <div className="flex items-center space-x-3 mb-3">
              <Avatar>
                <AvatarFallback>{user?.username.slice(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium text-sm">{user?.fullName || user?.username}</p>
                <p className="text-xs text-gray-500">{user?.email || user?.username}</p>
              </div>
            </div>
            <Link href="/settings" onClick={closeMobileMenu}>
              <div className="flex items-center space-x-2 px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-100 text-sm cursor-pointer">
                <Settings className="h-4 w-4" />
                <span>Settings</span>
              </div>
            </Link>
            <button 
              onClick={handleLogout}
              className="flex items-center space-x-2 px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-100 text-sm w-full text-left"
            >
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>
    </>
  );

  return (
    <>
      <MobileHeader />
      
      {/* Mobile Sidebar (slide in from left) */}
      <aside 
        className={`md:hidden fixed inset-0 z-50 transition-transform transform ${
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        } bg-white shadow-xl`}
      >
        <div className="flex justify-between items-center p-4 border-b">
          <div className="flex items-center space-x-3">
            <div className="h-8 w-8 bg-primary-500 text-white rounded-lg flex items-center justify-center">
              <DollarSign className="h-5 w-5" />
            </div>
            <h1 className="text-lg font-bold text-gray-800">ExpenseTrackerPro</h1>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={closeMobileMenu}
            aria-label="Close menu"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        <div className="flex flex-col h-[calc(100%-64px)]">
          <SidebarContent />
        </div>
      </aside>
      
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex md:w-64 flex-col sticky top-0 h-screen bg-white border-r border-gray-200 shadow-sm transition-all overflow-y-auto">
        <SidebarContent />
      </aside>
      
      {/* Backdrop for mobile menu */}
      {isMobileMenuOpen && (
        <div 
          className="md:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={closeMobileMenu}
        ></div>
      )}
    </>
  );
}
