import { createContext, ReactNode, useContext, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Budget, InsertBudget } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

type BudgetContextType = {
  budgets: Budget[] | undefined;
  isLoading: boolean;
  error: Error | null;
  createBudget: (data: InsertBudget) => Promise<Budget>;
  updateBudget: (id: number, data: Partial<InsertBudget>) => Promise<Budget | undefined>;
  deleteBudget: (id: number) => Promise<boolean>;
};

const BudgetContext = createContext<BudgetContextType | undefined>(undefined);

export function BudgetProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [error, setError] = useState<Error | null>(null);

  // Fetch budgets
  const { data: budgets, isLoading } = useQuery<Budget[]>({
    queryKey: ["/api/budgets"],
  });

  // Create budget mutation
  const createBudgetMutation = useMutation({
    mutationFn: async (data: InsertBudget) => {
      const res = await apiRequest("POST", "/api/budgets", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      toast({
        title: "Success",
        description: "Budget created successfully",
      });
    },
    onError: (error: Error) => {
      setError(error);
      toast({
        title: "Error",
        description: `Failed to create budget: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Update budget mutation
  const updateBudgetMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertBudget> }) => {
      const res = await apiRequest("PUT", `/api/budgets/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      toast({
        title: "Success",
        description: "Budget updated successfully",
      });
    },
    onError: (error: Error) => {
      setError(error);
      toast({
        title: "Error",
        description: `Failed to update budget: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Delete budget mutation
  const deleteBudgetMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/budgets/${id}`);
      return true;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      toast({
        title: "Success",
        description: "Budget deleted successfully",
      });
    },
    onError: (error: Error) => {
      setError(error);
      toast({
        title: "Error",
        description: `Failed to delete budget: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Public methods
  const createBudget = async (data: InsertBudget): Promise<Budget> => {
    return await createBudgetMutation.mutateAsync(data);
  };

  const updateBudget = async (id: number, data: Partial<InsertBudget>): Promise<Budget | undefined> => {
    return await updateBudgetMutation.mutateAsync({ id, data });
  };

  const deleteBudget = async (id: number): Promise<boolean> => {
    return await deleteBudgetMutation.mutateAsync(id);
  };

  return (
    <BudgetContext.Provider
      value={{
        budgets,
        isLoading,
        error,
        createBudget,
        updateBudget,
        deleteBudget,
      }}
    >
      {children}
    </BudgetContext.Provider>
  );
}

export function useBudgetContext() {
  const context = useContext(BudgetContext);
  if (context === undefined) {
    throw new Error("useBudgetContext must be used within a BudgetProvider");
  }
  return context;
}
