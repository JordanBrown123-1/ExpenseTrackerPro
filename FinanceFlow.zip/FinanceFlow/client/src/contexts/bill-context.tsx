import { createContext, ReactNode, useContext } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Bill, InsertBill } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type BillContextType = {
  bills: Bill[] | undefined;
  isLoading: boolean;
  error: Error | null;
  createBill: (data: Omit<InsertBill, 'userId'>) => Promise<Bill>;
  updateBill: (id: number, data: Partial<Omit<InsertBill, 'userId'>>) => Promise<Bill | undefined>;
  deleteBill: (id: number) => Promise<boolean>;
};

export const BillContext = createContext<BillContextType | null>(null);

export function BillProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  
  const {
    data: bills,
    error,
    isLoading
  } = useQuery<Bill[]>({
    queryKey: ["/api/bills"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: Omit<InsertBill, 'userId'>) => {
      const res = await apiRequest("POST", "/api/bills", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bills"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error creating bill",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Omit<InsertBill, 'userId'>> }) => {
      const res = await apiRequest("PUT", `/api/bills/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bills"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating bill",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/bills/${id}`);
      return true;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bills"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error deleting bill",
        description: error.message,
        variant: "destructive"
      });
      return false;
    }
  });

  const createBill = async (data: Omit<InsertBill, 'userId'>): Promise<Bill> => {
    return await createMutation.mutateAsync(data);
  };

  const updateBill = async (id: number, data: Partial<Omit<InsertBill, 'userId'>>): Promise<Bill | undefined> => {
    return await updateMutation.mutateAsync({ id, data });
  };

  const deleteBill = async (id: number): Promise<boolean> => {
    return await deleteMutation.mutateAsync(id);
  };

  return (
    <BillContext.Provider
      value={{
        bills,
        isLoading,
        error,
        createBill,
        updateBill,
        deleteBill
      }}
    >
      {children}
    </BillContext.Provider>
  );
}

export function useBillContext() {
  const context = useContext(BillContext);
  if (!context) {
    throw new Error("useBillContext must be used within a BillProvider");
  }
  return context;
}