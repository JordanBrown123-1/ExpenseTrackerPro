import { createContext, ReactNode, useContext, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Transaction, InsertTransaction } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

type TransactionContextType = {
  transactions: Transaction[] | undefined;
  isLoading: boolean;
  error: Error | null;
  createTransaction: (data: Omit<InsertTransaction, 'userId'>) => Promise<Transaction>;
  updateTransaction: (id: number, data: Partial<Omit<InsertTransaction, 'userId'>>) => Promise<Transaction | undefined>;
  deleteTransaction: (id: number) => Promise<boolean>;
};

const TransactionContext = createContext<TransactionContextType | undefined>(undefined);

export function TransactionProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [error, setError] = useState<Error | null>(null);

  // Fetch transactions
  const { data: transactions, isLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  // Create transaction mutation
  const createTransactionMutation = useMutation({
    mutationFn: async (data: Omit<InsertTransaction, 'userId'>) => {
      // userId will be added by the server from the authenticated user
      const res = await apiRequest("POST", "/api/transactions", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      toast({
        title: "Success",
        description: "Transaction created successfully",
      });
    },
    onError: (error: Error) => {
      setError(error);
      toast({
        title: "Error",
        description: `Failed to create transaction: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Update transaction mutation
  const updateTransactionMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Omit<InsertTransaction, 'userId'>> }) => {
      const res = await apiRequest("PATCH", `/api/transactions/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      toast({
        title: "Success",
        description: "Transaction updated successfully",
      });
    },
    onError: (error: Error) => {
      setError(error);
      toast({
        title: "Error",
        description: `Failed to update transaction: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Delete transaction mutation
  const deleteTransactionMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/transactions/${id}`);
      return true;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      toast({
        title: "Success",
        description: "Transaction deleted successfully",
      });
    },
    onError: (error: Error) => {
      setError(error);
      toast({
        title: "Error",
        description: `Failed to delete transaction: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Public methods
  const createTransaction = async (data: Omit<InsertTransaction, 'userId'>): Promise<Transaction> => {
    return await createTransactionMutation.mutateAsync(data);
  };

  const updateTransaction = async (id: number, data: Partial<Omit<InsertTransaction, 'userId'>>): Promise<Transaction | undefined> => {
    return await updateTransactionMutation.mutateAsync({ id, data });
  };

  const deleteTransaction = async (id: number): Promise<boolean> => {
    return await deleteTransactionMutation.mutateAsync(id);
  };

  return (
    <TransactionContext.Provider
      value={{
        transactions,
        isLoading,
        error,
        createTransaction,
        updateTransaction,
        deleteTransaction,
      }}
    >
      {children}
    </TransactionContext.Provider>
  );
}

export function useTransactionContext() {
  const context = useContext(TransactionContext);
  if (context === undefined) {
    throw new Error("useTransactionContext must be used within a TransactionProvider");
  }
  return context;
}
