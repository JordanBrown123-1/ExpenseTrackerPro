import { Transaction, Category } from "@shared/schema";
import { format } from "date-fns";

/**
 * Convert transactions data to CSV format and trigger download
 */
export function exportTransactionsToCSV(transactions: Transaction[], categories: Category[]) {
  // Define CSV headers
  const headers = ["Date", "Type", "Category", "Amount", "Description", "Notes"];
  
  // Map transactions to CSV rows
  const rows = transactions.map(transaction => {
    const category = categories.find(c => c.id === transaction.categoryId);
    const categoryName = category ? category.name : "Uncategorized";
    
    return [
      format(new Date(transaction.date), "yyyy-MM-dd"),
      transaction.type.charAt(0).toUpperCase() + transaction.type.slice(1),
      categoryName,
      transaction.amount.toFixed(2),
      transaction.description || "",
      transaction.notes || ""
    ];
  });
  
  // Combine headers and rows
  const csvContent = [
    headers.join(","),
    ...rows.map(row => row.join(","))
  ].join("\n");
  
  // Create a Blob with the CSV data
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  
  // Create a temporary link and trigger download
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute("download", `transactions_${format(new Date(), "yyyy-MM-dd")}.csv`);
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Export budget data to CSV
 */
export function exportBudgetsToCSV(budgets: any[], categories: Category[]) {
  // Define CSV headers
  const headers = ["Category", "Amount", "Period", "Start Date", "End Date"];
  
  // Map budgets to CSV rows
  const rows = budgets.map(budget => {
    const category = categories.find(c => c.id === budget.categoryId);
    const categoryName = category ? category.name : "Uncategorized";
    
    return [
      categoryName,
      budget.amount.toFixed(2),
      budget.period.charAt(0).toUpperCase() + budget.period.slice(1),
      format(new Date(budget.startDate), "yyyy-MM-dd"),
      budget.endDate ? format(new Date(budget.endDate), "yyyy-MM-dd") : ""
    ];
  });
  
  // Combine headers and rows
  const csvContent = [
    headers.join(","),
    ...rows.map(row => row.join(","))
  ].join("\n");
  
  // Create a Blob with the CSV data
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  
  // Create a temporary link and trigger download
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute("download", `budgets_${format(new Date(), "yyyy-MM-dd")}.csv`);
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Generate and download a summary report
 */
export function exportSummaryToCSV(summaryData: any, categories: Category[]) {
  const { summary, categorySpending, monthlyData } = summaryData;
  
  // Format the summary section
  const summarySection = [
    "# Financial Summary",
    `Report Date,${format(new Date(), "yyyy-MM-dd")}`,
    `Income,${summary.income.toFixed(2)}`,
    `Expenses,${summary.expenses.toFixed(2)}`,
    `Balance,${summary.balance.toFixed(2)}`,
    `Income Change,${summary.incomeChange.toFixed(2)}%`,
    `Expense Change,${summary.expenseChange.toFixed(2)}%`,
    `Budget Status,${summary.budgetStatus.toFixed(2)}%`,
    ""
  ].join("\n");
  
  // Format category spending section
  const categorySection = [
    "# Category Spending",
    "Category,Amount,Percentage",
    ...categorySpending.map((cat: any) => 
      `${cat.name},${cat.amount.toFixed(2)},${cat.percentage.toFixed(2)}%`
    ),
    ""
  ].join("\n");
  
  // Format monthly data section
  const monthlySection = [
    "# Monthly Overview",
    "Month,Income,Expenses",
    ...monthlyData.map((month: any) => 
      `${month.month},${month.income.toFixed(2)},${month.expenses.toFixed(2)}`
    )
  ].join("\n");
  
  // Combine all sections
  const csvContent = [
    summarySection,
    categorySection,
    monthlySection
  ].join("\n");
  
  // Create a Blob with the CSV data
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  
  // Create a temporary link and trigger download
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute("download", `financial_summary_${format(new Date(), "yyyy-MM-dd")}.csv`);
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}